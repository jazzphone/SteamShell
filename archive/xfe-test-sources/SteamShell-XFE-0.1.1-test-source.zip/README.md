# SteamShell XFE Companion

SteamShell XFE is a portable controller-utility companion for Windows Xbox Full
Screen Experience. It is a separate application from SteamShell 1.5.0 and does
not replace, install, or modify the Windows shell.

The current test candidate is **0.1.1**. It keeps Quick Menu controls alive
while navigating to eliminate full-window flashing, centers from the rendered
window size on the foreground monitor, and uses the familiar SteamShell
sidebar/category Settings layout.

## Recommended AnyFSE configuration

1. Select AnyFSE's built-in **Steam Big Picture** launcher.
2. Add `SteamShell-XFE.exe` as an AnyFSE startup application.
3. Turn **Exit FSE when Home app exits** off.
4. Do not select SteamShell XFE itself as the custom Home app.

This lets AnyFSE/Xbox FSE own the Home-app lifecycle, fullscreen presentation,
taskbar, window sizing, focus, and desktop transitions. The companion remains
alive if Steam closes or restarts.

## Included

- Controller-first Quick Menu (hold L3 + R3)
- Audio output, volume, and mute
- Resolution/refresh selection with a 15-second automatic revert
- Windows HDR toggle
- RTSS overlay and frame-limiter shortcuts
- Configurable View/Back controller mappings
- Controller mouse, touch keyboard, and classic OSK
- Sleep-safe cursor hiding and cursor parking
- Native Task View, Game Bar, and Windows Desktop actions
- Settings editor, portable INI, health check, and heartbeat log
- Sleep, restart, and shutdown controls with confirmation

## Deliberately excluded

- Winlogon shell registration or repair
- Explorer launch/kill/monitor logic
- Taskbar hiding or guarding
- Window centering, maximization, scoring, or focus enforcement
- AlwaysFocus, custom task switcher, or focus pinning
- Steam launch, recovery, refocus, or exit monitoring
- Splash video, startup-program editor, launcher cleanup, or installer

Those responsibilities overlap Xbox FSE and would create two competing window
and lifecycle managers.

## Build

Install AutoHotkey v2 with Ahk2Exe, then run PowerShell:

```powershell
.\Build-SteamShell-XFE.ps1
```

The script validates with the installed 64-bit AutoHotkey interpreter before
compiling `dist\SteamShell-XFE.exe`.

## Keyboard fallbacks

- `Ctrl+Alt+Shift+Q` — Quick Menu
- `Ctrl+Alt+Shift+S` — Settings
- `Ctrl+Alt+Shift+R` — reload INI
- `Ctrl+Alt+Shift+X` — exit companion

The executable is portable. Its INI and log are created beside it.
