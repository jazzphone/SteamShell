param([switch]$Quiet)

$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$sourcePath = Join-Path $projectRoot "SteamShell-XFE.ahk"
$samplePath = Join-Path $projectRoot "SteamShell-XFE_SAMPLE.ini"

function Assert-True {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) {
        throw $Message
    }
}

Assert-True (Test-Path $sourcePath) "SteamShell-XFE.ahk is missing."
Assert-True (Test-Path $samplePath) "SteamShell-XFE_SAMPLE.ini is missing."
$source = Get-Content -LiteralPath $sourcePath -Raw
$sample = Get-Content -LiteralPath $samplePath -Raw

$functionMatches = [regex]::Matches(
    $source,
    '(?m)^([A-Za-z_][A-Za-z0-9_]*)\([^\r\n{}]*\)\s*\{')
$duplicates = $functionMatches |
    Group-Object { $_.Groups[1].Value.ToLowerInvariant() } |
    Where-Object Count -gt 1
Assert-True ($duplicates.Count -eq 0) (
    "Duplicate top-level functions: " +
    (($duplicates | ForEach-Object Name) -join ", "))

$functionNames = @{}
foreach ($match in $functionMatches) {
    $functionNames[$match.Groups[1].Value.ToLowerInvariant()] = $true
}
$assignments = [regex]::Matches(
    $source,
    '(?m)^\s*([A-Za-z_][A-Za-z0-9_]*)\s*:=')
$collisions = @(
    $assignments |
        Where-Object {
            $functionNames.ContainsKey($_.Groups[1].Value.ToLowerInvariant())
        } |
        ForEach-Object { $_.Groups[1].Value } |
        Sort-Object -Unique
)
Assert-True ($collisions.Count -eq 0) (
    "Variables shadow AutoHotkey function names: " + ($collisions -join ", "))

$requiredFunctions = @(
    "PollController",
    "ShowQuickMenu",
    "QuickMenuRender",
    "ShowSettings",
    "SettingsShowCategory",
    "ShowMappingEditor",
    "OpenTouchKeyboard",
    "ParkCursor",
    "ObserveForeground",
    "GetPrimaryDisplayModes",
    "ApplyPrimaryDisplayMode",
    "SetDefaultAudioEndpointId",
    "EnsureRtssRunning",
    "ShowHealthCheck"
)
foreach ($required in $requiredFunctions) {
    Assert-True $functionNames.ContainsKey($required.ToLowerInvariant()) (
        "Required companion function is missing: $required")
}

Assert-True ($source -match '(?m)^#Requires AutoHotkey v2\.0\.19 64-bit$') (
    "The 64-bit AutoHotkey v2 requirement is missing.")
Assert-True ($source -match '(?m)^#SingleInstance Ignore$') (
    "The XFE companion must not replace a surviving instance during re-entry.")
Assert-True ($source -match '(?m)^#NoTrayIcon$') (
    "The living-room companion must remain trayless.")
Assert-True ($source -notmatch '(?i)Run\s*\(\s*["'']\*RunAs') (
    "Automatic elevation is not allowed in the XFE companion.")

# Architecture boundary: these responsibilities belong to Windows Xbox FSE.
$forbidden = @(
    'CurrentVersion\\Winlogon',
    'RegWrite\s*\(',
    'RegDelete\s*\(',
    'HideShellTaskbars',
    'TaskbarGuard',
    'WindowEngine',
    'AlwaysFocus',
    'RestoreExplorerDesktop',
    'EnableSteamRefocus',
    'GameMinScoreToActivate',
    'SetWinEventHook'
)
foreach ($pattern in $forbidden) {
    Assert-True ($source -notmatch $pattern) (
        "Forbidden shell/window-engine responsibility detected: $pattern")
}

$parkFunctionMatch = [regex]::Match(
    $source,
    '(?ms)^ParkCursor\([^)]*\)\s*\{.*?^}\s*(?=^[A-Za-z_][A-Za-z0-9_]*\s*\()')
Assert-True (
    $parkFunctionMatch.Success -and
    $parkFunctionMatch.Value -match 'SetCursorPos' -and
    $parkFunctionMatch.Value -notmatch 'MouseMove\(') (
    "Cursor parking must use SetCursorPos so it does not reset Windows idle time.")
Assert-True (
    $source -match '(?s)DisplayPendingUntilTick\s*:=\s*A_TickCount\s*\+\s*15000' -and
    $source -match 'DisplayChangeSafetyTick') (
    "The 15-second display-mode safety revert is missing.")
Assert-True (
    $source -match '(?s)QuickMenuRefresh\(\)\s*\{.*?QuickMenuRender\(\)' -and
    $source -notmatch '(?s)QuickMenuRefresh\(\)\s*\{.*?QuickMenuGui\.Destroy\(') (
    "Quick Menu selection refresh must update persistent controls without rebuilding the GUI.")
Assert-True ($source -notmatch 'Add\(\s*"Tab3"') (
    "The overlapping tabbed Settings layout has returned.")
Assert-True (
    $source -match 'SettingsCategoryList' -and
    $source -match 'SettingsChangeCategory\(') (
    "The sidebar Settings category navigation is incomplete.")

$schemaVersion = [regex]::Match(
    $source, '(?m)^global SettingsSchemaVersion\s*:=\s*(\d+)$')
Assert-True $schemaVersion.Success "Runtime settings schema version is missing."
Assert-True (
    $sample -match "(?m)^SettingsSchemaVersion=$($schemaVersion.Groups[1].Value)$") (
    "Sample and runtime settings schema versions do not match.")
Assert-True ($sample -match '(?m)^ControllerDeadzone=4000$') (
    "The sample controller deadzone default must remain 4000.")

if (-not $Quiet) {
    Write-Host "SteamShell XFE static validation passed."
}
