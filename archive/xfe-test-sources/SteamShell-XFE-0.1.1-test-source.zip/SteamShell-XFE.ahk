; ==============================================================================
; SteamShell XFE Companion
; Controller-first utilities for Windows Xbox Full Screen Experience.
;
; This is intentionally NOT a Windows shell, Steam launcher, taskbar guard,
; Explorer manager, window scorer, or focus engine. Xbox FSE owns those jobs.
;
; Hotkeys:
; Ctrl+Alt+Shift+Q  Quick Menu
; Ctrl+Alt+Shift+S  Settings
; Ctrl+Alt+Shift+R  Reload settings
; Ctrl+Alt+Shift+X  Exit companion
; ==============================================================================
#Requires AutoHotkey v2.0.19 64-bit
#SingleInstance Ignore
#NoTrayIcon
Persistent
SendMode "Input"
SetTitleMatchMode 2

global AppVersion := "0.1.1"
global SettingsSchemaVersion := 1
global IniPath := A_ScriptDir "\SteamShell-XFE.ini"
global LogPath := A_ScriptDir "\SteamShell-XFE.log"
global ScriptPid := DllCall("GetCurrentProcessId", "UInt")
global XInputDll := ""
global LastStatusText := "Ready"
global LastStatusLevel := "Info"

; Runtime configuration.
global HeartbeatSeconds := 60
global EnableQuickMenu := true
global QuickMenuChordHoldMs := 700
global EnableControllerMouseMode := true
global ControllerIndex := 0
global ControllerPollIntervalMs := 16
global ControllerDeadzone := 4000
global ControllerMouseSpeed := 100
global ControllerMouseFastMultiplier := 2.5
global ControllerScrollIntervalMs := 80
global ControllerScrollStep := 1
global ControllerChordHoldMs := 500
global EnableAutoHideCursor := true
global MouseHideDelayMs := 1000
global ParkOnStartup := true
global ParkOnSteamReturn := true
global ParkYPercent := 0.50
global ForegroundPollMs := 500
global EnableAudioQuickControls := true
global EnableDisplayQuickControls := true
global EnableRTSSIntegration := false
global RtssPath := "C:\Program Files (x86)\RivaTuner Statistics Server\RTSS.exe"
global RtssOverlayControlMode := "separate"
global RtssOverlayToggleShortcut := "^+o"
global RtssOverlayOnShortcut := "^+1"
global RtssOverlayOffShortcut := "^+2"
global RtssFrameLimiterControlMode := "separate"
global RtssCustomFrameCap := 0
global RtssCustomFrameCapShortcut := "^+f"
global RtssFrameLimiterOnShortcut := "^+5"
global RtssFrameLimiterOffShortcut := "^+6"

; Controller mappings are active while View/Back is held.
global ControllerMap := Map()
global ControllerMapDisplay := Map()

; Cursor and foreground observer state.
global MouseHidden := false
global LastMouseX := -99999
global LastMouseY := -99999
global LastMouseMoveTick := A_TickCount
global LastObservedForegroundExe := ""

; Quick Menu state.
global QuickMenuGui := unset
global QuickMenuVisible := false
global QuickMenuPage := "MAIN"
global QuickMenuRows := []
global QuickMenuSelected := 1
global QuickMenuTitleCtrl := 0
global QuickMenuStatusCtrl := 0
global QuickMenuLabelCtrls := []
global QuickMenuValueCtrls := []
global QuickMenuMonitorIndex := 1
global QuickMenuDisplayModes := []
global QuickMenuDisplayPage := 1
global QuickMenuAudioDevices := []
global QuickMenuConfirmAction := ""
global QuickMenuConfirmUntilTick := 0
global DisplayPendingOldMode := 0
global DisplayPendingUntilTick := 0

; Settings and shortcut-capture state.
global SettingsGui := unset
global SettingsFields := Map()
global SettingsVisible := false
global SettingsDirty := false
global SettingsDialogActive := false
global SettingsCategoryControls := Map()
global SettingsCategoryList := 0
global SettingsCategoryTitleCtrl := 0
global SettingsCategoryDescriptionCtrl := 0
global SettingsCurrentCategory := 1
global MappingGui := unset
global MappingList := 0
global _ShortcutCap := ""

DefaultSettings() {
    return Map(
        "Companion", Map(
            "SettingsSchemaVersion", 1,
            "HeartbeatSeconds", 60
        ),
        "QuickMenu", Map(
            "Enable", "true",
            "ChordHoldMs", 700
        ),
        "Controller", Map(
            "EnableControllerMouseMode", "true",
            "ControllerIndex", 0,
            "ControllerPollIntervalMs", 16,
            "ControllerDeadzone", 4000,
            "ControllerMouseSpeed", 100,
            "ControllerMouseFastMultiplier", 2.5,
            "ControllerScrollIntervalMs", 80,
            "ControllerScrollStep", 1,
            "ControllerChordHoldMs", 500
        ),
        "Cursor", Map(
            "EnableAutoHide", "true",
            "HideDelayMs", 1000,
            "ParkOnStartup", "true",
            "ParkOnSteamReturn", "true",
            "ParkYPercent", 0.50,
            "ForegroundPollMs", 500
        ),
        "Audio", Map(
            "EnableQuickControls", "true"
        ),
        "Display", Map(
            "EnableQuickControls", "true"
        ),
        "RTSS", Map(
            "EnableIntegration", "false",
            "Path", "C:\Program Files (x86)\RivaTuner Statistics Server\RTSS.exe",
            "OverlayControlMode", "separate",
            "OverlayToggleShortcut", "^+o",
            "OverlayOnShortcut", "^+1",
            "OverlayOffShortcut", "^+2",
            "FrameLimiterControlMode", "separate",
            "CustomFrameCap", 0,
            "CustomFrameCapShortcut", "^+f",
            "FrameLimiterOnShortcut", "^+5",
            "FrameLimiterOffShortcut", "^+6"
        )
    )
}

DefaultControllerMappings() {
    global ControllerMap, ControllerMapDisplay
    ControllerMap := Map(
        "RB.Short", "Builtin:LeftClick", "RB.Long", "Builtin:None",
        "RT.Short", "Builtin:RightClick", "RT.Long", "Builtin:None",
        "LT.Short", "Send:^+o", "LT.Long", "Send:^+f",
        "LB.Short", "Send:^!{Tab}", "LB.Long", "Builtin:TaskManager",
        "A.Short", "Builtin:Enter", "A.Long", "Builtin:None",
        "B.Short", "Builtin:Esc", "B.Long", "Builtin:AltF4",
        "X.Short", "Builtin:TabTip", "X.Long", "Builtin:OSK",
        "Y.Short", "Builtin:WinG", "Y.Long", "Builtin:None",
        "Start.Short", "Builtin:StartMenu", "Start.Long", "Builtin:Explorer",
        "L3.Short", "Builtin:None", "L3.Long", "Builtin:None",
        "R3.Short", "Builtin:None", "R3.Long", "Builtin:None"
    )
    ControllerMapDisplay := Map(
        "LT.Short", "Ctrl+Shift+O",
        "LT.Long", "Ctrl+Shift+F",
        "LB.Short", "Ctrl+Alt+Tab"
    )
}

EnsureSettingsFile() {
    global IniPath, SettingsSchemaVersion, ControllerMap, ControllerMapDisplay
    defaults := DefaultSettings()
    for section, values in defaults {
        for key, value in values {
            marker := "__STEAMSHELL_XFE_MISSING__"
            current := marker
            try current := IniRead(IniPath, section, key, marker)
            if (current = marker)
                IniWrite(value, IniPath, section, key)
        }
    }
    IniWrite(SettingsSchemaVersion, IniPath, "Companion", "SettingsSchemaVersion")

    DefaultControllerMappings()
    for key, value in ControllerMap {
        marker := "__STEAMSHELL_XFE_MISSING__"
        current := marker
        try current := IniRead(IniPath, "ControllerMap", key, marker)
        if (current = marker)
            IniWrite(value, IniPath, "ControllerMap", key)
        if (SubStr(value, 1, 5) = "Send:" && ControllerMapDisplay.Has(key)) {
            displayKey := key ".Display"
            displayCurrent := marker
            try displayCurrent := IniRead(IniPath, "ControllerMap", displayKey, marker)
            if (displayCurrent = marker)
                IniWrite(ControllerMapDisplay[key], IniPath, "ControllerMap", displayKey)
        }
    }
}

ReadBool(section, key, fallback) {
    global IniPath
    value := ""
    try value := IniRead(IniPath, section, key, fallback ? "true" : "false")
    value := StrLower(Trim(value))
    return value = "1" || value = "true" || value = "yes" || value = "on"
}

ReadInt(section, key, fallback, minimum, maximum) {
    global IniPath
    value := fallback
    try value := Round(IniRead(IniPath, section, key, fallback))
    catch
        value := fallback
    return Max(minimum, Min(maximum, value))
}

ReadNumber(section, key, fallback, minimum, maximum) {
    global IniPath
    value := fallback
    try value := IniRead(IniPath, section, key, fallback) + 0
    catch
        value := fallback
    return Max(minimum, Min(maximum, value))
}

ReadText(section, key, fallback := "") {
    global IniPath
    value := fallback
    try value := IniRead(IniPath, section, key, fallback)
    return Trim(value)
}

LoadSettings() {
    global HeartbeatSeconds, EnableQuickMenu, QuickMenuChordHoldMs
    global EnableControllerMouseMode, ControllerIndex, ControllerPollIntervalMs
    global ControllerDeadzone, ControllerMouseSpeed, ControllerMouseFastMultiplier
    global ControllerScrollIntervalMs, ControllerScrollStep, ControllerChordHoldMs
    global EnableAutoHideCursor, MouseHideDelayMs, ParkOnStartup
    global ParkOnSteamReturn, ParkYPercent, ForegroundPollMs
    global EnableAudioQuickControls, EnableDisplayQuickControls
    global EnableRTSSIntegration, RtssPath, RtssOverlayControlMode
    global RtssOverlayToggleShortcut, RtssOverlayOnShortcut, RtssOverlayOffShortcut
    global RtssFrameLimiterControlMode, RtssCustomFrameCap
    global RtssCustomFrameCapShortcut, RtssFrameLimiterOnShortcut, RtssFrameLimiterOffShortcut

    HeartbeatSeconds := ReadInt("Companion", "HeartbeatSeconds", 60, 15, 3600)
    EnableQuickMenu := ReadBool("QuickMenu", "Enable", true)
    QuickMenuChordHoldMs := ReadInt("QuickMenu", "ChordHoldMs", 700, 250, 3000)
    EnableControllerMouseMode := ReadBool("Controller", "EnableControllerMouseMode", true)
    ControllerIndex := ReadInt("Controller", "ControllerIndex", 0, 0, 3)
    ControllerPollIntervalMs := ReadInt("Controller", "ControllerPollIntervalMs", 16, 8, 100)
    ControllerDeadzone := ReadInt("Controller", "ControllerDeadzone", 4000, 1000, 16000)
    ControllerMouseSpeed := ReadInt("Controller", "ControllerMouseSpeed", 100, 10, 300)
    ControllerMouseFastMultiplier := ReadNumber("Controller", "ControllerMouseFastMultiplier", 2.5, 1, 6)
    ControllerScrollIntervalMs := ReadInt("Controller", "ControllerScrollIntervalMs", 80, 20, 500)
    ControllerScrollStep := ReadInt("Controller", "ControllerScrollStep", 1, 1, 10)
    ControllerChordHoldMs := ReadInt("Controller", "ControllerChordHoldMs", 500, 200, 3000)
    EnableAutoHideCursor := ReadBool("Cursor", "EnableAutoHide", true)
    MouseHideDelayMs := ReadInt("Cursor", "HideDelayMs", 1000, 250, 10000)
    ParkOnStartup := ReadBool("Cursor", "ParkOnStartup", true)
    ParkOnSteamReturn := ReadBool("Cursor", "ParkOnSteamReturn", true)
    ParkYPercent := ReadNumber("Cursor", "ParkYPercent", 0.50, 0.05, 0.95)
    ForegroundPollMs := ReadInt("Cursor", "ForegroundPollMs", 500, 250, 5000)
    EnableAudioQuickControls := ReadBool("Audio", "EnableQuickControls", true)
    EnableDisplayQuickControls := ReadBool("Display", "EnableQuickControls", true)
    EnableRTSSIntegration := ReadBool("RTSS", "EnableIntegration", false)
    RtssPath := ReadText("RTSS", "Path", "C:\Program Files (x86)\RivaTuner Statistics Server\RTSS.exe")
    RtssOverlayControlMode := StrLower(ReadText("RTSS", "OverlayControlMode", "separate"))
    RtssOverlayToggleShortcut := ReadText("RTSS", "OverlayToggleShortcut", "^+o")
    RtssOverlayOnShortcut := ReadText("RTSS", "OverlayOnShortcut", "^+1")
    RtssOverlayOffShortcut := ReadText("RTSS", "OverlayOffShortcut", "^+2")
    RtssFrameLimiterControlMode := StrLower(ReadText("RTSS", "FrameLimiterControlMode", "separate"))
    RtssCustomFrameCap := ReadInt("RTSS", "CustomFrameCap", 0, 0, 1000)
    RtssCustomFrameCapShortcut := ReadText("RTSS", "CustomFrameCapShortcut", "^+f")
    RtssFrameLimiterOnShortcut := ReadText("RTSS", "FrameLimiterOnShortcut", "^+5")
    RtssFrameLimiterOffShortcut := ReadText("RTSS", "FrameLimiterOffShortcut", "^+6")
    LoadControllerMappings()
}

LoadControllerMappings() {
    global IniPath, ControllerMap, ControllerMapDisplay
    DefaultControllerMappings()
    keys := [
        "A.Short", "A.Long", "B.Short", "B.Long", "X.Short", "X.Long",
        "Y.Short", "Y.Long", "LB.Short", "LB.Long", "RB.Short", "RB.Long",
        "LT.Short", "LT.Long", "RT.Short", "RT.Long", "Start.Short",
        "Start.Long", "L3.Short", "L3.Long", "R3.Short", "R3.Long"
    ]
    for key in keys {
        value := ""
        try value := IniRead(IniPath, "ControllerMap", key, "")
        if (value = "")
            continue
        if (SubStr(value, 1, 5) != "Send:" && SubStr(value, 1, 8) != "Builtin:")
            value := "Send:" value
        ControllerMap[key] := value
        if (SubStr(value, 1, 5) = "Send:") {
            display := ""
            try display := IniRead(IniPath, "ControllerMap", key ".Display", "")
            ControllerMapDisplay[key] := display != "" ? display : SendToPretty(SubStr(value, 6))
        }
    }
}

ApplyRuntimeTimers() {
    global ControllerPollIntervalMs, EnableAutoHideCursor, ForegroundPollMs
    global HeartbeatSeconds
    SetTimer(PollController, 0)
    SetTimer(MouseWatch, 0)
    SetTimer(ObserveForeground, 0)
    SetTimer(Heartbeat, 0)
    SetTimer(PollController, ControllerPollIntervalMs)
    if EnableAutoHideCursor
        SetTimer(MouseWatch, 250)
    SetTimer(ObserveForeground, ForegroundPollMs)
    SetTimer(Heartbeat, HeartbeatSeconds * 1000)
}

ReloadSettings(*) {
    global QuickMenuVisible, SettingsVisible
    EnsureSettingsFile()
    LoadSettings()
    ApplyRuntimeTimers()
    if QuickMenuVisible
        QuickMenuBuildGui()
    if SettingsVisible
        SettingsPopulate()
    SetStatus("Settings reloaded", "Info")
}

LogLine(message, level := "Info") {
    global LogPath
    line := FormatTime(, "yyyy-MM-dd HH:mm:ss") " [" level "] " message "`r`n"
    try FileAppend(line, LogPath, "UTF-8")
}

SetStatus(message, level := "Info") {
    global LastStatusText, LastStatusLevel, QuickMenuVisible
    LastStatusText := message
    LastStatusLevel := level
    LogLine(message, level)
    if QuickMenuVisible
        try QuickMenuRefresh()
}

Heartbeat() {
    global AppVersion
    LogLine("Heartbeat: XFE companion " AppVersion " is responsive.")
}

OnCompanionExit(exitReason, exitCode) {
    global DisplayPendingOldMode
    SetTimer(PollController, 0)
    SetTimer(MouseWatch, 0)
    SetTimer(ObserveForeground, 0)
    if IsObject(DisplayPendingOldMode)
        ApplyPrimaryDisplayMode(DisplayPendingOldMode)
    try SystemCursor("Show")
    LogLine("Stopped (" exitReason ", code " exitCode ").")
}

ExitCompanion(*) {
    ExitApp()
}

SendChordSafe(keys) {
    try SendInput("{Ctrl up}{Alt up}{Shift up}{LWin up}{RWin up}")
    try SendInput(keys)
}

NormalizePath(path) {
    path := Trim(path, " `t`r`n`"")
    return path
}

IsOurWindow(hwnd) {
    global ScriptPid
    if !hwnd
        return false
    pid := 0
    try pid := WinGetPID("ahk_id " hwnd)
    return pid = ScriptPid
}

GetMonitorWorkAreaForPoint(x, y, &left, &top, &right, &bottom) {
    count := MonitorGetCount()
    Loop count {
        MonitorGetWorkArea(A_Index, &ml, &mt, &mr, &mb)
        if (x >= ml && x < mr && y >= mt && y < mb) {
            left := ml, top := mt, right := mr, bottom := mb
            return A_Index
        }
    }
    MonitorGetWorkArea(1, &left, &top, &right, &bottom)
    return 1
}

CenterGuiOnCursor(guiObj, width, height) {
    MouseGetPos(&mx, &my)
    GetMonitorWorkAreaForPoint(mx, my, &left, &top, &right, &bottom)
    x := left + Floor(((right - left) - width) / 2)
    y := top + Floor(((bottom - top) - height) / 2)
    guiObj.Show("x" x " y" y " w" width " h" height)
}

GetMonitorIndexForWindow(hwnd) {
    if hwnd {
        try {
            WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " hwnd)
            centerX := wx + Floor(ww / 2)
            centerY := wy + Floor(wh / 2)
            count := MonitorGetCount()
            Loop count {
                MonitorGet(A_Index, &left, &top, &right, &bottom)
                if (centerX >= left && centerX < right
                    && centerY >= top && centerY < bottom)
                    return A_Index
            }
        }
    }
    MouseGetPos(&mx, &my)
    return GetMonitorWorkAreaForPoint(mx, my, &left, &top, &right, &bottom)
}

CenterGuiOnMonitorActual(guiObj, monitorIndex, width, height, noActivate := false) {
    monitorIndex := Max(1, Min(MonitorGetCount(), monitorIndex))
    MonitorGetWorkArea(monitorIndex, &left, &top, &right, &bottom)

    ; Render hidden once so Windows supplies the real non-client dimensions.
    guiObj.Show("Hide w" width " h" height)
    actualWidth := width
    actualHeight := height
    try WinGetPos(, , &actualWidth, &actualHeight, "ahk_id " guiObj.Hwnd)
    x := left + Floor(((right - left) - actualWidth) / 2)
    y := top + Floor(((bottom - top) - actualHeight) / 2)
    option := noActivate ? "NA " : ""
    guiObj.Show(option "x" x " y" y " w" width " h" height)
}

; ==============================================================================
; Cursor hiding and sleep-safe parking
; ==============================================================================
SystemCursor(mode := "Show") {
    static AndM := Buffer(128, 0xFF)
    static XorM := Buffer(128, 0)
    static Cursors := [32512,32513,32514,32515,32516,32640,32641,32642,
        32643,32644,32645,32646,32648,32649,32650,32651]
    if (mode = "Hide") {
        for _, id in Cursors {
            hCur := DllCall("CreateCursor", "Ptr", 0, "Int", 0, "Int", 0,
                "Int", 32, "Int", 32, "Ptr", AndM, "Ptr", XorM, "Ptr")
            DllCall("SetSystemCursor", "Ptr", hCur, "Int", id)
        }
    } else {
        DllCall("SystemParametersInfo", "UInt", 0x57, "UInt", 0, "Ptr", 0, "UInt", 0)
    }
}

MouseWatch() {
    global EnableAutoHideCursor, MouseHidden, LastMouseX, LastMouseY
    global LastMouseMoveTick, MouseHideDelayMs, QuickMenuVisible, SettingsVisible
    if !EnableAutoHideCursor
        return
    MouseGetPos(&mx, &my)
    if (mx != LastMouseX || my != LastMouseY) {
        LastMouseX := mx
        LastMouseY := my
        LastMouseMoveTick := A_TickCount
        if MouseHidden {
            SystemCursor("Show")
            MouseHidden := false
        }
        return
    }
    if (QuickMenuVisible || SettingsVisible)
        return
    if (!MouseHidden && A_TickCount - LastMouseMoveTick >= MouseHideDelayMs) {
        SystemCursor("Hide")
        MouseHidden := true
    }
}

ParkCursor(*) {
    global ParkYPercent, LastMouseX, LastMouseY, LastMouseMoveTick
    global EnableAutoHideCursor, MouseHidden
    hwnd := 0
    try hwnd := WinExist("A")
    if hwnd {
        try {
            WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " hwnd)
            targetX := wx + Max(2, Min(ww - 2, 4))
            targetY := wy + Round(wh * ParkYPercent)
        } catch {
            MouseGetPos(&mx, &my)
            GetMonitorWorkAreaForPoint(mx, my, &left, &top, &right, &bottom)
            targetX := left + 4
            targetY := top + Round((bottom - top) * ParkYPercent)
        }
    } else {
        MouseGetPos(&mx, &my)
        GetMonitorWorkAreaForPoint(mx, my, &left, &top, &right, &bottom)
        targetX := left + 4
        targetY := top + Round((bottom - top) * ParkYPercent)
    }
    DllCall("SetCursorPos", "Int", targetX, "Int", targetY)
    LastMouseX := targetX
    LastMouseY := targetY
    LastMouseMoveTick := A_TickCount
    if EnableAutoHideCursor {
        SystemCursor("Hide")
        MouseHidden := true
    }
}

ObserveForeground() {
    global LastObservedForegroundExe, ParkOnSteamReturn
    hwnd := 0
    try hwnd := WinExist("A")
    if (!hwnd || IsOurWindow(hwnd))
        return
    exe := ""
    try exe := StrLower(WinGetProcessName("ahk_id " hwnd))
    if (exe = "")
        return
    wasSteam := LastObservedForegroundExe = "steam.exe" || LastObservedForegroundExe = "steamwebhelper.exe"
    isSteam := exe = "steam.exe" || exe = "steamwebhelper.exe"
    previous := LastObservedForegroundExe
    LastObservedForegroundExe := exe
    if (ParkOnSteamReturn && isSteam && !wasSteam && previous != "")
        SetTimer(ParkCursor, -500)
}

; ==============================================================================
; XInput and controller mappings
; ==============================================================================
InitXInput() {
    global XInputDll
    if (XInputDll != "")
        return true
    for _, dll in ["xinput1_4.dll", "xinput1_3.dll", "xinput9_1_0.dll"] {
        try {
            if (DllCall("GetModuleHandle", "Str", dll, "Ptr")
                || DllCall("LoadLibrary", "Str", dll, "Ptr")) {
                XInputDll := dll
                return true
            }
        }
    }
    XInputDll := ""
    return false
}

XInputGetState(index, &state) {
    global XInputDll
    if (XInputDll = "" && !InitXInput())
        return 1167
    if !IsObject(state)
        state := Buffer(16, 0)
    try {
        rc := DllCall(XInputDll "\XInputGetState", "UInt", index, "Ptr", state, "UInt")
        if (rc = 0) {
            try {
                extended := Buffer(16, 0)
                if (DllCall(XInputDll "\100", "UInt", index, "Ptr", extended, "UInt") = 0) {
                    exButtons := NumGet(extended, 4, "UShort")
                    if (exButtons & 0x0400) {
                        buttons := NumGet(state, 4, "UShort")
                        NumPut("UShort", buttons | 0x0400, state, 4)
                    }
                }
            }
        }
        return rc
    } catch {
        XInputDll := ""
        return 1
    }
}

HasLongBinding(buttonName) {
    global ControllerMap
    value := ""
    try value := ControllerMap[buttonName ".Long"]
    return value != "" && value != "Builtin:None"
}

GetBindingValue(key) {
    global ControllerMap
    value := ""
    try value := ControllerMap[key]
    return value
}

ExecuteControllerBinding(key) {
    value := GetBindingValue(key)
    if (value = "" || value = "Builtin:None")
        return
    if (SubStr(value, 1, 5) = "Send:") {
        shortcut := SubStr(value, 6)
        if (shortcut != "")
            SendChordSafe(shortcut)
        return
    }
    if (SubStr(value, 1, 8) != "Builtin:")
        return
    action := SubStr(value, 9)
    switch action {
        case "LeftClick":
            try Click("Left")
        case "RightClick":
            try Click("Right")
        case "Enter":
            try SendInput("{Enter}")
        case "Esc":
            try SendInput("{Esc}")
        case "AltF4":
            SendChordSafe("!{F4}")
        case "TabTip":
            OpenTouchKeyboard()
        case "OSK":
            OpenOSK()
        case "WinG":
            SendChordSafe("#g")
        case "StartMenu":
            try SendInput("{LWin}")
        case "Explorer":
            try Run("explorer.exe")
        case "CtrlAltTab":
            SendChordSafe("^!{Tab}")
        case "TaskManager":
            SendChordSafe("^+{Esc}")
        case "TaskView":
            SendChordSafe("#{Tab}")
        case "WindowsDesktop":
            SendChordSafe("#F11")
        case "QuickMenu":
            ToggleQuickMenu()
        case "Settings":
            ShowSettings()
    }
}

SendToPretty(shortcut) {
    text := shortcut
    text := StrReplace(text, "#", "Win+")
    text := StrReplace(text, "^", "Ctrl+")
    text := StrReplace(text, "!", "Alt+")
    text := StrReplace(text, "+", "Shift+")
    text := StrReplace(text, "{Tab}", "Tab")
    text := StrReplace(text, "{Esc}", "Esc")
    text := StrReplace(text, "{Enter}", "Enter")
    text := StrReplace(text, "{F4}", "F4")
    return text
}

ControllerBindingPretty(key) {
    global ControllerMapDisplay
    value := GetBindingValue(key)
    if (value = "")
        return "None"
    if (SubStr(value, 1, 5) = "Send:") {
        try return ControllerMapDisplay[key]
        return SendToPretty(SubStr(value, 6))
    }
    if (SubStr(value, 1, 8) = "Builtin:") {
        action := SubStr(value, 9)
        labels := Map(
            "None", "None", "LeftClick", "Left click", "RightClick", "Right click",
            "Enter", "Enter", "Esc", "Back / Escape", "AltF4", "Close window",
            "TabTip", "Touch keyboard", "OSK", "Classic keyboard",
            "WinG", "Game Bar", "StartMenu", "Start menu", "Explorer", "File Explorer",
            "CtrlAltTab", "Application switcher", "TaskManager", "Task Manager",
            "TaskView", "Task View", "WindowsDesktop", "Windows desktop",
            "QuickMenu", "Quick Menu", "Settings", "Settings"
        )
        return labels.Has(action) ? labels[action] : action
    }
    return value
}

; ==============================================================================
; Touch keyboard
; ==============================================================================
TryInvokeTouchKeyboard() {
    static clsidText := "{4CE576FA-83DC-4F88-951C-9D0782B4E376}"
    static iidText := "{37C994E7-432B-4834-A2F7-DCE1F13B834B}"
    clsid := Buffer(16, 0)
    iid := Buffer(16, 0)
    tip := 0
    if (DllCall("Ole32\CLSIDFromString", "WStr", clsidText, "Ptr", clsid.Ptr, "Int") != 0
        || DllCall("Ole32\CLSIDFromString", "WStr", iidText, "Ptr", iid.Ptr, "Int") != 0)
        return false
    hr := DllCall("Ole32\CoCreateInstance", "Ptr", clsid.Ptr, "Ptr", 0,
        "UInt", 0x5, "Ptr", iid.Ptr, "Ptr*", &tip, "Int")
    if (hr < 0 || !tip)
        return false
    succeeded := false
    try {
        vtable := NumGet(tip, 0, "Ptr")
        method := NumGet(vtable, 3 * A_PtrSize, "Ptr")
        desktop := DllCall("User32\GetDesktopWindow", "Ptr")
        succeeded := DllCall(method, "Ptr", tip, "Ptr", desktop, "Int") >= 0
    } finally {
        try {
            vtable := NumGet(tip, 0, "Ptr")
            release := NumGet(vtable, 2 * A_PtrSize, "Ptr")
            DllCall(release, "Ptr", tip, "UInt")
        }
    }
    return succeeded
}

RunViaDesktopShell(filePath, arguments := "", directory := "", show := 1) {
    static VT_UI4 := 0x13
    static SWC_DESKTOP := ComValue(VT_UI4, 0x8)
    try {
        ComObject("Shell.Application").Windows.Item(SWC_DESKTOP).Document.Application
            .ShellExecute(filePath, arguments, directory, "open", show)
        return true
    } catch {
        return false
    }
}

OpenTouchKeyboard() {
    if WinExist("ahk_class IPTip_Main_Window") {
        try WinShow("ahk_class IPTip_Main_Window")
        try WinActivate("ahk_class IPTip_Main_Window")
        return
    }
    if TryInvokeTouchKeyboard()
        return
    paths := [A_ProgramFiles "\Common Files\microsoft shared\ink\TabTip.exe"]
    try {
        pf86 := EnvGet("ProgramFiles(x86)")
        if (pf86 != "")
            paths.Push(pf86 "\Common Files\microsoft shared\ink\TabTip.exe")
    }
    tabTip := ""
    for _, path in paths {
        if FileExist(path) {
            tabTip := path
            break
        }
    }
    if (tabTip = "") {
        OpenOSK()
        return
    }
    SplitPath(tabTip, , &directory)
    if !ProcessExist("TabTip.exe") {
        if !RunViaDesktopShell(tabTip, "", directory) {
            OpenOSK()
            return
        }
    }
    Sleep 250
    if !TryInvokeTouchKeyboard() {
        if !RunViaDesktopShell(tabTip, "/SeekDesktop", directory)
            OpenOSK()
    }
}

OpenOSK() {
    try Run("osk.exe")
}

; ==============================================================================
; Audio, display, HDR, and RTSS
; ==============================================================================
GetActiveAudioOutputDevices() {
    devices := []
    iidDevice := "{D666063F-1587-4E43-81F1-B948E807363F}"
    Loop 32 {
        index := A_Index
        try name := SoundGetName(, index)
        catch
            break
        if (name = "")
            continue
        try {
            device := SoundGetInterface(iidDevice, , index)
            idPtr := 0
            ComCall(5, device, "Ptr*", &idPtr)
            id := idPtr ? StrGet(idPtr, "UTF-16") : ""
            if idPtr
                DllCall("Ole32\CoTaskMemFree", "Ptr", idPtr)
            if (id != "")
                devices.Push(Map("name", name, "id", id))
        }
    }
    return devices
}

SetDefaultAudioEndpointId(endpointId) {
    if (endpointId = "")
        return false
    policy := 0
    try policy := ComObject(
        "{870AF99C-171D-4F9E-AF0D-E63DF40C2BC9}",
        "{F8679F50-850A-41CF-9C72-430F290290C8}")
    catch {
        try policy := ComObject(
            "{294935CE-F637-4E7C-A41B-AB255460B862}",
            "{568B9108-44BF-40B4-9006-86AFE5B5A620}")
    }
    if !IsObject(policy)
        return false
    try {
        ComCall(13, policy, "WStr", endpointId, "Int", 0)
        ComCall(13, policy, "WStr", endpointId, "Int", 1)
        ComCall(13, policy, "WStr", endpointId, "Int", 2)
        return true
    } catch {
        return false
    }
}

CycleDefaultAudioOutput(direction) {
    global QuickMenuAudioDevices
    QuickMenuAudioDevices := GetActiveAudioOutputDevices()
    if (QuickMenuAudioDevices.Length = 0) {
        SetStatus("No active audio outputs were found", "Warning")
        return
    }
    currentName := ""
    try currentName := SoundGetName()
    currentIndex := 1
    for index, device in QuickMenuAudioDevices {
        if (device["name"] = currentName) {
            currentIndex := index
            break
        }
    }
    nextIndex := currentIndex + direction
    if (nextIndex < 1)
        nextIndex := QuickMenuAudioDevices.Length
    if (nextIndex > QuickMenuAudioDevices.Length)
        nextIndex := 1
    target := QuickMenuAudioDevices[nextIndex]
    if SetDefaultAudioEndpointId(target["id"])
        SetStatus("Audio output: " target["name"])
    else
        SetStatus("Windows could not switch the audio output", "Warning")
}

GetPrimaryDisplayMode() {
    dm := Buffer(220, 0)
    NumPut("UShort", 220, dm, 68)
    try {
        if !DllCall("User32\EnumDisplaySettingsW", "Ptr", 0, "Int", -1, "Ptr", dm, "Int")
            return 0
    } catch {
        return 0
    }
    return Map(
        "width", NumGet(dm, 172, "UInt"),
        "height", NumGet(dm, 176, "UInt"),
        "frequency", NumGet(dm, 184, "UInt")
    )
}

GetPrimaryDisplayModes() {
    modes := []
    seen := Map()
    modeIndex := 0
    Loop 512 {
        dm := Buffer(220, 0)
        NumPut("UShort", 220, dm, 68)
        ok := false
        try ok := DllCall("User32\EnumDisplaySettingsW", "Ptr", 0,
            "UInt", modeIndex, "Ptr", dm, "Int")
        if !ok
            break
        modeIndex += 1
        width := NumGet(dm, 172, "UInt")
        height := NumGet(dm, 176, "UInt")
        frequency := NumGet(dm, 184, "UInt")
        bpp := NumGet(dm, 168, "UInt")
        if (width < 640 || height < 480 || frequency < 24 || bpp < 24)
            continue
        key := width "x" height "@" frequency
        if seen.Has(key)
            continue
        seen[key] := true
        modes.Push(Map("width", width, "height", height, "frequency", frequency))
    }
    sorted := []
    for _, mode in modes {
        insertAt := sorted.Length + 1
        for pos, existing in sorted {
            lhs := mode["width"] * mode["height"]
            rhs := existing["width"] * existing["height"]
            if (lhs < rhs || (lhs = rhs && mode["frequency"] < existing["frequency"])) {
                insertAt := pos
                break
            }
        }
        sorted.InsertAt(insertAt, mode)
    }
    return sorted
}

ApplyPrimaryDisplayMode(mode) {
    if !IsObject(mode)
        return false
    dm := Buffer(220, 0)
    NumPut("UShort", 220, dm, 68)
    NumPut("UInt", 0x580000, dm, 72)
    NumPut("UInt", mode["width"], dm, 172)
    NumPut("UInt", mode["height"], dm, 176)
    NumPut("UInt", mode["frequency"], dm, 184)
    try {
        result := DllCall("User32\ChangeDisplaySettingsExW", "Ptr", 0,
            "Ptr", dm, "Ptr", 0, "UInt", 0, "Ptr", 0, "Int")
        return result = 0
    } catch {
        return false
    }
}

SelectPrimaryDisplayMode(modeIndex) {
    global QuickMenuDisplayModes, QuickMenuDisplayPage, QuickMenuSelected
    global DisplayPendingOldMode, DisplayPendingUntilTick
    if (modeIndex < 1 || modeIndex > QuickMenuDisplayModes.Length)
        return
    current := GetPrimaryDisplayMode()
    if !IsObject(current) {
        SetStatus("Current display mode is unavailable", "Warning")
        return
    }
    candidate := QuickMenuDisplayModes[modeIndex]
    same := candidate["width"] = current["width"]
        && candidate["height"] = current["height"]
        && candidate["frequency"] = current["frequency"]
    if IsObject(DisplayPendingOldMode) {
        if same
            ConfirmPrimaryDisplayMode()
        else
            SetStatus("Keep or revert the pending display change first", "Warning")
        return
    }
    if same
        return
    if ApplyPrimaryDisplayMode(candidate) {
        DisplayPendingOldMode := current
        DisplayPendingUntilTick := A_TickCount + 15000
        QuickMenuDisplayPage := Ceil(modeIndex / 7)
        QuickMenuSelected := 2 + Mod(modeIndex - 1, 7)
        SetTimer(DisplayChangeSafetyTick, 500)
        SetStatus("Display changed. Select CURRENT again within 15 seconds to keep it.", "Warning")
    } else {
        SetStatus("Windows rejected that display mode", "Warning")
    }
}

ConfirmPrimaryDisplayMode() {
    global DisplayPendingOldMode, DisplayPendingUntilTick
    if !IsObject(DisplayPendingOldMode)
        return
    DisplayPendingOldMode := 0
    DisplayPendingUntilTick := 0
    SetTimer(DisplayChangeSafetyTick, 0)
    SetStatus("Display mode kept")
}

DisplayChangeSafetyTick() {
    global DisplayPendingOldMode, DisplayPendingUntilTick, QuickMenuVisible
    if !IsObject(DisplayPendingOldMode) {
        SetTimer(DisplayChangeSafetyTick, 0)
        return
    }
    if (A_TickCount >= DisplayPendingUntilTick) {
        oldMode := DisplayPendingOldMode
        DisplayPendingOldMode := 0
        DisplayPendingUntilTick := 0
        SetTimer(DisplayChangeSafetyTick, 0)
        if ApplyPrimaryDisplayMode(oldMode)
            SetStatus("Display mode reverted for safety", "Warning")
        else
            SetStatus("Unable to restore the previous display mode", "Warning")
    }
    if QuickMenuVisible
        QuickMenuRefresh()
}

EnsureRtssRunning() {
    global RtssPath
    if ProcessExist("RTSS.exe")
        return true
    path := NormalizePath(RtssPath)
    if (path = "" || !FileExist(path))
        return false
    try {
        Run('"' path '"', , "Min")
        return ProcessWait("RTSS.exe", 3) != 0
    } catch {
        return false
    }
}

SendRtssShortcut(shortcut, description) {
    global EnableRTSSIntegration
    if !EnableRTSSIntegration {
        SetStatus("Enable RTSS integration in Settings first", "Warning")
        return false
    }
    if (shortcut = "") {
        SetStatus("Configure the RTSS shortcut in Settings first", "Warning")
        return false
    }
    if !EnsureRtssRunning() {
        SetStatus("RTSS was not found at the configured path", "Warning")
        return false
    }
    SendChordSafe(shortcut)
    SetStatus(description)
    return true
}

ToggleRtssOverlay() {
    global RtssOverlayToggleShortcut
    SendRtssShortcut(RtssOverlayToggleShortcut, "RTSS overlay toggled")
}

SetRtssOverlayState(enabled) {
    global RtssOverlayOnShortcut, RtssOverlayOffShortcut
    shortcut := enabled ? RtssOverlayOnShortcut : RtssOverlayOffShortcut
    SendRtssShortcut(shortcut, enabled ? "RTSS overlay enabled" : "RTSS overlay disabled")
}

ToggleRtssFrameLimiter() {
    global RtssCustomFrameCapShortcut
    SendRtssShortcut(RtssCustomFrameCapShortcut, "RTSS frame limiter toggled")
}

SetRtssFrameLimiterState(enabled) {
    global RtssFrameLimiterOnShortcut, RtssFrameLimiterOffShortcut
    shortcut := enabled ? RtssFrameLimiterOnShortcut : RtssFrameLimiterOffShortcut
    SendRtssShortcut(shortcut,
        enabled ? "RTSS frame limiter enabled" : "RTSS frame limiter disabled")
}

; ==============================================================================
; Controller-first Quick Menu
; ==============================================================================
MenuRow(id, label, value := "", action := "", adjustable := false) {
    return Map(
        "id", id,
        "label", label,
        "value", value,
        "action", action,
        "adjustable", adjustable
    )
}

QuickMenuGetRows() {
    global QuickMenuPage, EnableAudioQuickControls, EnableDisplayQuickControls
    global QuickMenuDisplayModes, QuickMenuDisplayPage
    global RtssOverlayControlMode, RtssFrameLimiterControlMode
    rows := []
    switch QuickMenuPage {
        case "MAIN":
            if EnableAudioQuickControls
                rows.Push(MenuRow("audioPage", "Audio", GetAudioSummary(), "page:AUDIO"))
            if EnableDisplayQuickControls
                rows.Push(MenuRow("displayPage", "Display & HDR", GetDisplaySummary(), "page:DISPLAY"))
            rows.Push(MenuRow("rtssPage", "RTSS & Performance", GetRtssSummary(), "page:RTSS"))
            rows.Push(MenuRow("layoutPage", "Controller Layout", "View mappings", "page:LAYOUT"))
            rows.Push(MenuRow("taskView", "Task View", "Windows native", "taskView"))
            rows.Push(MenuRow("gameBar", "Game Bar", "Win + G", "gameBar"))
            rows.Push(MenuRow("windowsDesktop", "Windows Desktop", "Win + F11", "windowsDesktop"))
            rows.Push(MenuRow("settings", "Settings", "Companion configuration", "settings"))
            rows.Push(MenuRow("systemPage", "System", "Power & diagnostics", "page:SYSTEM"))
        case "AUDIO":
            rows.Push(MenuRow("back", "Back", "", "back"))
            rows.Push(MenuRow("audioOutput", "Output", GetAudioOutputName(), "audioOutput", true))
            rows.Push(MenuRow("volume", "Volume", GetVolumeText(), "volume", true))
            rows.Push(MenuRow("mute", "Mute", GetMuteText(), "mute"))
        case "DISPLAY":
            rows.Push(MenuRow("back", "Back", "", "back"))
            rows.Push(MenuRow("hdr", "HDR", "Toggle", "hdr"))
            if (QuickMenuDisplayModes.Length = 0)
                QuickMenuDisplayModes := GetPrimaryDisplayModes()
            pageCount := Max(1, Ceil(QuickMenuDisplayModes.Length / 7))
            QuickMenuDisplayPage := Max(1, Min(pageCount, QuickMenuDisplayPage))
            startIndex := (QuickMenuDisplayPage - 1) * 7 + 1
            endIndex := Min(QuickMenuDisplayModes.Length, startIndex + 6)
            if (QuickMenuDisplayModes.Length = 0) {
                rows.Push(MenuRow("displayUnavailable", "No compatible modes reported", "", "none"))
            } else {
                Loop endIndex - startIndex + 1 {
                    index := startIndex + A_Index - 1
                    mode := QuickMenuDisplayModes[index]
                    label := mode["width"] " × " mode["height"]
                    rows.Push(MenuRow("displayMode:" index, label,
                        GetDisplayModeValue(index), "displayMode:" index))
                }
            }
            if (pageCount > 1) {
                rows.Push(MenuRow("displayPrev", "Previous Page",
                    QuickMenuDisplayPage " / " pageCount, "displayPrev"))
                rows.Push(MenuRow("displayNext", "Next Page",
                    QuickMenuDisplayPage " / " pageCount, "displayNext"))
            }
        case "RTSS":
            rows.Push(MenuRow("back", "Back", "", "back"))
            if (RtssOverlayControlMode = "separate") {
                rows.Push(MenuRow("overlayOn", "Overlay On", "", "overlayOn"))
                rows.Push(MenuRow("overlayOff", "Overlay Off", "", "overlayOff"))
            } else {
                rows.Push(MenuRow("overlayToggle", "Toggle Overlay", "", "overlayToggle"))
            }
            if (RtssFrameLimiterControlMode = "separate") {
                rows.Push(MenuRow("limiterOn", "Frame Limiter On",
                    GetFrameCapLabel(), "limiterOn"))
                rows.Push(MenuRow("limiterOff", "Frame Limiter Off", "", "limiterOff"))
            } else {
                rows.Push(MenuRow("limiterToggle", "Toggle Frame Limiter",
                    GetFrameCapLabel(), "limiterToggle"))
            }
            rows.Push(MenuRow("rtssSettings", "RTSS Settings", GetRtssSummary(), "settings"))
        case "LAYOUT":
            rows.Push(MenuRow("back", "Back", "", "back"))
            for _, button in ["A", "B", "X", "Y", "LB", "RB", "LT", "RT", "Start", "L3", "R3"] {
                value := ControllerBindingPretty(button ".Short")
                longValue := ControllerBindingPretty(button ".Long")
                if (longValue != "None")
                    value .= "  /  hold: " longValue
                rows.Push(MenuRow("layout:" button, button, value, "none"))
            }
        case "SYSTEM":
            rows.Push(MenuRow("back", "Back", "", "back"))
            rows.Push(MenuRow("health", "Run Health Check", "", "health"))
            rows.Push(MenuRow("sleep", "Sleep", "", "sleep"))
            rows.Push(MenuRow("restart", "Restart", "", "restart"))
            rows.Push(MenuRow("shutdown", "Shut Down", "", "shutdown"))
            rows.Push(MenuRow("exit", "Exit Companion", "", "exit"))
    }
    return rows
}

GuiSafeLabel(text) {
    return StrReplace(text, "&", "&&")
}

ShortText(text, maxChars) {
    text := Trim(text)
    return StrLen(text) <= maxChars ? text : SubStr(text, 1, maxChars - 1) "…"
}

GetAudioOutputName() {
    try return ShortText(SoundGetName(), 34)
    return "Unavailable"
}

GetVolumeText() {
    try return Round(SoundGetVolume()) "%"
    return "Unavailable"
}

GetMuteText() {
    try return SoundGetMute() ? "ON" : "OFF"
    return "Unavailable"
}

GetAudioSummary() {
    return GetVolumeText() "  •  " GetAudioOutputName()
}

GetDisplaySummary() {
    mode := GetPrimaryDisplayMode()
    if !IsObject(mode)
        return "Unavailable"
    return mode["width"] "×" mode["height"] "  •  " mode["frequency"] " Hz"
}

GetDisplayModeValue(index) {
    global QuickMenuDisplayModes, DisplayPendingOldMode, DisplayPendingUntilTick
    if (index < 1 || index > QuickMenuDisplayModes.Length)
        return ""
    candidate := QuickMenuDisplayModes[index]
    current := GetPrimaryDisplayMode()
    if (IsObject(current)
        && candidate["width"] = current["width"]
        && candidate["height"] = current["height"]
        && candidate["frequency"] = current["frequency"]) {
        if IsObject(DisplayPendingOldMode) {
            remaining := Max(0, Ceil((DisplayPendingUntilTick - A_TickCount) / 1000))
            return "CURRENT — select to keep (" remaining "s)"
        }
        return "CURRENT  •  " candidate["frequency"] " Hz"
    }
    return candidate["frequency"] " Hz"
}

GetRtssSummary() {
    global EnableRTSSIntegration, RtssPath
    if !EnableRTSSIntegration
        return "Setup required"
    if ProcessExist("RTSS.exe")
        return "RTSS running"
    return FileExist(NormalizePath(RtssPath)) ? "RTSS ready" : "RTSS not found"
}

GetFrameCapLabel() {
    global RtssCustomFrameCap
    return RtssCustomFrameCap > 0 ? RtssCustomFrameCap " FPS preset" : "RTSS preset"
}

ToggleQuickMenu(*) {
    global QuickMenuVisible
    if QuickMenuVisible
        HideQuickMenu()
    else
        ShowQuickMenu()
}

ShowQuickMenu(*) {
    global EnableQuickMenu, QuickMenuVisible, QuickMenuPage, QuickMenuSelected
    global QuickMenuMonitorIndex
    if !EnableQuickMenu
        return
    foreground := 0
    try foreground := WinExist("A")
    QuickMenuMonitorIndex := GetMonitorIndexForWindow(foreground)
    QuickMenuPage := "MAIN"
    QuickMenuSelected := 1
    QuickMenuVisible := true
    QuickMenuBuildGui()
}

HideQuickMenu(*) {
    global QuickMenuVisible, QuickMenuGui, EnableAutoHideCursor, MouseHidden
    if IsSet(QuickMenuGui)
        try QuickMenuGui.Hide()
    QuickMenuVisible := false
    if EnableAutoHideCursor {
        SystemCursor("Hide")
        MouseHidden := true
    }
}

QuickMenuTitle() {
    global QuickMenuPage
    titles := Map(
        "MAIN", "SteamShell XFE",
        "AUDIO", "Audio",
        "DISPLAY", "Display & HDR",
        "RTSS", "RTSS & Performance",
        "LAYOUT", "Controller Layout",
        "SYSTEM", "System"
    )
    return titles.Has(QuickMenuPage) ? titles[QuickMenuPage] : "SteamShell XFE"
}

QuickMenuBuildGui() {
    global QuickMenuGui, QuickMenuTitleCtrl, QuickMenuStatusCtrl
    global QuickMenuLabelCtrls, QuickMenuValueCtrls
    global QuickMenuVisible, QuickMenuMonitorIndex, QuickMenuRows
    if !QuickMenuVisible
        return
    width := 720
    if !IsSet(QuickMenuGui) {
        menu := Gui("+AlwaysOnTop -Caption +ToolWindow +Border", "SteamShell XFE Quick Menu")
        menu.BackColor := "171A21"
        menu.MarginX := 24
        menu.MarginY := 18
        menu.SetFont("s19 cFFFFFF Bold", "Segoe UI")
        QuickMenuTitleCtrl := menu.AddText("x24 y18 w672 h36", "")
        menu.SetFont("s9 cAAB2C0 Norm", "Segoe UI")
        menu.AddText("x24 y54 w672 h24",
            "D-pad navigate  •  A select  •  B back  •  Left/Right adjust")
        QuickMenuLabelCtrls := []
        QuickMenuValueCtrls := []
        Loop 14 {
            index := A_Index
            y := 78 + ((index - 1) * 38)
            menu.SetFont("s12 cD9DEE8 Norm", "Segoe UI")
            labelCtrl := menu.AddText("x24 y" y " w350 h30 +0x200", "")
            labelCtrl.OnEvent("Click", QuickMenuMouseActivate.Bind(index))
            menu.SetFont("s10 c99A3B3 Norm", "Segoe UI")
            valueCtrl := menu.AddText("x380 y" y " w310 h30 Right +0x200", "")
            valueCtrl.OnEvent("Click", QuickMenuMouseActivate.Bind(index))
            QuickMenuLabelCtrls.Push(labelCtrl)
            QuickMenuValueCtrls.Push(valueCtrl)
        }
        menu.SetFont("s9 c8E98A8 Norm", "Segoe UI")
        QuickMenuStatusCtrl := menu.AddText("x24 y680 w672 h42 +Wrap", "")
        menu.OnEvent("Escape", HideQuickMenu)
        QuickMenuGui := menu
    }
    QuickMenuRender()
    rowHeight := 38
    height := Min(118 + (QuickMenuRows.Length * rowHeight) + 58, 820)
    CenterGuiOnMonitorActual(QuickMenuGui, QuickMenuMonitorIndex, width, height)
}

QuickMenuRender() {
    global QuickMenuRows, QuickMenuSelected, QuickMenuTitleCtrl, QuickMenuStatusCtrl
    global QuickMenuLabelCtrls, QuickMenuValueCtrls
    global LastStatusText, LastStatusLevel, QuickMenuVisible
    if !QuickMenuVisible
        return
    QuickMenuRows := QuickMenuGetRows()
    if (QuickMenuRows.Length = 0)
        return
    QuickMenuSelected := Max(1, Min(QuickMenuRows.Length, QuickMenuSelected))
    QuickMenuTitleCtrl.Text := GuiSafeLabel(QuickMenuTitle())
    Loop QuickMenuLabelCtrls.Length {
        index := A_Index
        labelCtrl := QuickMenuLabelCtrls[index]
        valueCtrl := QuickMenuValueCtrls[index]
        if (index > QuickMenuRows.Length) {
            labelCtrl.Visible := false
            valueCtrl.Visible := false
            continue
        }
        row := QuickMenuRows[index]
        selected := index = QuickMenuSelected
        labelCtrl.Visible := true
        valueCtrl.Visible := true
        labelCtrl.Text := (selected ? "▶  " : "    ") GuiSafeLabel(row["label"])
        valueCtrl.Text := GuiSafeLabel(row["value"])
        labelCtrl.SetFont("s12 c" (selected ? "FFFFFF Bold" : "D9DEE8 Norm"),
            "Segoe UI")
        valueCtrl.SetFont("s10 c" (selected ? "8ED0FF" : "99A3B3") " Norm",
            "Segoe UI")
    }
    statusY := 81 + (QuickMenuRows.Length * 38)
    QuickMenuStatusCtrl.Move(24, statusY, 672, 42)
    QuickMenuStatusCtrl.Text := GuiSafeLabel(LastStatusText)
    QuickMenuStatusCtrl.SetFont(
        "s9 c" (LastStatusLevel = "Warning" ? "FFCA70" : "8E98A8") " Norm",
        "Segoe UI")
}

QuickMenuRefresh() {
    global QuickMenuVisible
    if QuickMenuVisible
        QuickMenuRender()
}

QuickMenuMouseActivate(index, *) {
    global QuickMenuSelected, QuickMenuRows
    if (index < 1 || index > QuickMenuRows.Length)
        return
    QuickMenuSelected := index
    QuickMenuActivateSelected()
}

QuickMenuGoBack() {
    global QuickMenuPage, QuickMenuSelected
    if (QuickMenuPage = "MAIN") {
        HideQuickMenu()
        return
    }
    QuickMenuPage := "MAIN"
    QuickMenuSelected := 1
    QuickMenuBuildGui()
}

QuickMenuConfirm(id, description) {
    global QuickMenuConfirmAction, QuickMenuConfirmUntilTick
    if (QuickMenuConfirmAction = id && A_TickCount < QuickMenuConfirmUntilTick) {
        QuickMenuConfirmAction := ""
        return true
    }
    QuickMenuConfirmAction := id
    QuickMenuConfirmUntilTick := A_TickCount + 5000
    SetStatus("Select again within 5 seconds to confirm " description, "Warning")
    return false
}

QuickMenuActivateSelected() {
    global QuickMenuRows, QuickMenuSelected, QuickMenuPage, QuickMenuDisplayPage
    if (QuickMenuRows.Length = 0)
        return
    action := QuickMenuRows[QuickMenuSelected]["action"]
    if (SubStr(action, 1, 5) = "page:") {
        QuickMenuPage := SubStr(action, 6)
        QuickMenuSelected := 1
        QuickMenuBuildGui()
        return
    }
    if (SubStr(action, 1, 12) = "displayMode:") {
        SelectPrimaryDisplayMode(Round(SubStr(action, 13) + 0))
        QuickMenuRefresh()
        return
    }
    switch action {
        case "none":
            return
        case "back":
            QuickMenuGoBack()
            return
        case "audioOutput":
            CycleDefaultAudioOutput(1)
        case "volume":
            QuickMenuAdjustSelected(1)
        case "mute":
            try {
                SoundSetMute(-1)
                SetStatus(SoundGetMute() ? "Audio muted" : "Audio unmuted")
            } catch {
                SetStatus("Windows mute control is unavailable", "Warning")
            }
        case "hdr":
            SendChordSafe("#!b")
            SetStatus("Windows HDR toggle requested")
        case "displayPrev":
            QuickMenuDisplayPage := Max(1, QuickMenuDisplayPage - 1)
        case "displayNext":
            QuickMenuDisplayPage += 1
        case "overlayToggle":
            ToggleRtssOverlay()
        case "overlayOn":
            SetRtssOverlayState(true)
        case "overlayOff":
            SetRtssOverlayState(false)
        case "limiterToggle":
            ToggleRtssFrameLimiter()
        case "limiterOn":
            SetRtssFrameLimiterState(true)
        case "limiterOff":
            SetRtssFrameLimiterState(false)
        case "taskView":
            HideQuickMenu()
            SendChordSafe("#{Tab}")
            return
        case "gameBar":
            HideQuickMenu()
            SendChordSafe("#g")
            return
        case "windowsDesktop":
            HideQuickMenu()
            SendChordSafe("#F11")
            return
        case "settings":
            HideQuickMenu()
            ShowSettings()
            return
        case "health":
            ShowHealthCheck()
            return
        case "sleep":
            if !QuickMenuConfirm("sleep", "sleep")
                return
            HideQuickMenu()
            try DllCall("PowrProf\SetSuspendState", "Int", 0, "Int", 0, "Int", 0)
            return
        case "restart":
            if !QuickMenuConfirm("restart", "restart")
                return
            HideQuickMenu()
            try Shutdown(2)
            return
        case "shutdown":
            if !QuickMenuConfirm("shutdown", "shutdown")
                return
            HideQuickMenu()
            try Shutdown(1)
            return
        case "exit":
            if !QuickMenuConfirm("exit", "exit")
                return
            HideQuickMenu()
            ExitApp()
    }
    QuickMenuRefresh()
}

QuickMenuAdjustSelected(direction) {
    global QuickMenuRows, QuickMenuSelected
    if (QuickMenuRows.Length = 0)
        return
    action := QuickMenuRows[QuickMenuSelected]["action"]
    switch action {
        case "audioOutput":
            CycleDefaultAudioOutput(direction)
        case "volume":
            try {
                nextVolume := Max(0, Min(100, Round(SoundGetVolume()) + direction * 5))
                SoundSetVolume(nextVolume)
                SetStatus("Volume " nextVolume "%")
            } catch {
                SetStatus("Windows volume control is unavailable", "Warning")
            }
        case "displayPrev":
            if (direction < 0)
                QuickMenuActivateSelected()
        case "displayNext":
            if (direction > 0)
                QuickMenuActivateSelected()
    }
    QuickMenuRefresh()
}

QuickMenuHandleController(pressed, lx, ly) {
    global QuickMenuRows, QuickMenuSelected
    if (pressed & 0x0001) {
        QuickMenuSelected -= 1
        if (QuickMenuSelected < 1)
            QuickMenuSelected := QuickMenuRows.Length
        QuickMenuRefresh()
        return
    }
    if (pressed & 0x0002) {
        QuickMenuSelected += 1
        if (QuickMenuSelected > QuickMenuRows.Length)
            QuickMenuSelected := 1
        QuickMenuRefresh()
        return
    }
    if (pressed & 0x0004) {
        QuickMenuAdjustSelected(-1)
        return
    }
    if (pressed & 0x0008) {
        QuickMenuAdjustSelected(1)
        return
    }
    if (pressed & 0x1000) {
        QuickMenuActivateSelected()
        return
    }
    if (pressed & 0x2000) {
        QuickMenuGoBack()
        return
    }
}

; ==============================================================================
; Settings GUI
; ==============================================================================
AddSettingField(guiObj, key, type, options, value, label := "") {
    global SettingsFields
    if (type = "Checkbox") {
        control := guiObj.Add(type, options, GuiSafeLabel(label))
        SettingsFields[key] := control
        control.OnEvent("Click", SettingsMarkDirty)
        return control
    }
    if (label != "")
        guiObj.AddText("xm y+10 w250 h24 +0x200", GuiSafeLabel(label))
    control := guiObj.Add(type, options, value)
    SettingsFields[key] := control
    try control.OnEvent("Change", SettingsMarkDirty)
    try control.OnEvent("Click", SettingsMarkDirty)
    return control
}

SettingsMarkDirty(*) {
    global SettingsDirty
    SettingsDirty := true
    SettingsUpdateStatus()
}

SettingsUpdateStatus(message := "") {
    global SettingsGui, SettingsDirty
    if !IsSet(SettingsGui)
        return
    text := message != "" ? message : (SettingsDirty ? "Unsaved changes" : "All changes saved")
    try SettingsGui["SettingsStatus"].Text := text
}

ShowSettings(*) {
    global SettingsGui, SettingsVisible, SettingsFields, SettingsDirty
    global SettingsCategoryControls, SettingsCategoryList
    global SettingsCategoryTitleCtrl, SettingsCategoryDescriptionCtrl
    global SettingsCurrentCategory, MouseHidden, IniPath, LogPath
    if SettingsVisible {
        try SettingsGui.Show()
        try WinActivate("ahk_id " SettingsGui.Hwnd)
        return
    }
    if MouseHidden {
        SystemCursor("Show")
        MouseHidden := false
    }
    SettingsFields := Map()
    SettingsCategoryControls := Map(
        "General", [],
        "Controller & Cursor", [],
        "RTSS & Performance", [],
        "Advanced", []
    )
    SettingsDirty := false
    SettingsCurrentCategory := 1
    settings := Gui("-Resize +MinSize900x600", "SteamShell XFE Settings")
    settings.Opt("+OwnDialogs")
    settings.MarginX := 24
    settings.MarginY := 16
    settings.SetFont("s18 Bold", "Segoe UI")
    settings.AddText("x24 y16 w860 h34", "SteamShell XFE Settings")
    settings.SetFont("s9 Norm", "Segoe UI")
    settings.AddText("x24 y52 w870 h24",
        "Right stick pointer • RB click • D-pad navigate • LT/RT categories • X keyboard • Y save")
    SettingsCategoryList := settings.AddListBox(
        "x24 y96 w225 h455 Choose1",
        ["General", "Controller & Cursor", "RTSS & Performance", "Advanced"])
    SettingsCategoryList.OnEvent("Change", SettingsCategoryChanged)
    settings.AddText("x264 y96 w1 h455 +0x10")
    settings.SetFont("s16 Bold", "Segoe UI")
    SettingsCategoryTitleCtrl := settings.AddText("x286 y96 w610 h32", "General")
    settings.SetFont("s9 Norm", "Segoe UI")
    SettingsCategoryDescriptionCtrl := settings.AddText(
        "x286 y132 w610 h42 +Wrap",
        "Quick Menu, heartbeat, and the controls shown in the living-room interface.")

    ; General
    settings.SetFont("s10", "Segoe UI")
    control := settings.AddCheckbox("x300 y190 w550 h26", "Enable controller Quick Menu")
    SettingsRegisterField("General", "QuickMenu.Enable", control, "Click")
    SettingsAddEditRow(settings, "General", "QuickMenu.ChordHoldMs",
        "Quick Menu L3 + R3 hold (ms)", 230, true)
    SettingsAddEditRow(settings, "General", "Companion.HeartbeatSeconds",
        "Heartbeat log interval (seconds)", 270, true)
    control := settings.AddCheckbox("x300 y320 w550 h26", "Show audio controls")
    SettingsRegisterField("General", "Audio.EnableQuickControls", control, "Click")
    control := settings.AddCheckbox("x300 y356 w550 h26", "Show display and HDR controls")
    SettingsRegisterField("General", "Display.EnableQuickControls", control, "Click")
    control := settings.AddText("x300 y410 w570 h76 +Wrap",
        "Integration: configure AnyFSE to launch Steam Big Picture as the Home app, "
        . "add SteamShell-XFE.exe as a startup app, and leave “Exit FSE when Home app exits” off.")
    SettingsTrackControl("General", control)

    ; Controller & Cursor
    control := settings.AddCheckbox(
        "x300 y190 w570 h26", "Enable View/Back controller mappings and mouse mode")
    SettingsRegisterField(
        "Controller & Cursor", "Controller.EnableControllerMouseMode", control, "Click")
    SettingsAddEditRow(settings, "Controller & Cursor", "Controller.ControllerIndex",
        "Controller index (0–3)", 230, true)
    SettingsAddEditRow(settings, "Controller & Cursor", "Controller.ControllerDeadzone",
        "Stick deadzone", 270, true)
    SettingsAddEditRow(settings, "Controller & Cursor", "Controller.ControllerMouseSpeed",
        "Pointer speed", 310, true)
    SettingsAddEditRow(settings, "Controller & Cursor", "Controller.ControllerChordHoldMs",
        "Long-press threshold (ms)", 350, true)
    control := settings.AddCheckbox("x300 y400 w570 h26", "Hide the cursor after inactivity")
    SettingsRegisterField("Controller & Cursor", "Cursor.EnableAutoHide", control, "Click")
    SettingsAddEditRow(settings, "Controller & Cursor", "Cursor.HideDelayMs",
        "Cursor hide delay (ms)", 435, true)
    control := settings.AddCheckbox("x300 y480 w320 h26", "Park the cursor at startup")
    SettingsRegisterField("Controller & Cursor", "Cursor.ParkOnStartup", control, "Click")
    control := settings.AddCheckbox("x300 y515 w320 h26", "Park after returning to Steam")
    SettingsRegisterField("Controller & Cursor", "Cursor.ParkOnSteamReturn", control, "Click")
    mapButton := settings.AddButton("x650 y480 w220 h34", "Controller Mappings...")
    mapButton.OnEvent("Click", ShowMappingEditor)
    SettingsTrackControl("Controller & Cursor", mapButton)

    ; RTSS & Performance
    control := settings.AddCheckbox("x300 y180 w570 h26", "Enable RTSS integration")
    SettingsRegisterField("RTSS & Performance", "RTSS.EnableIntegration", control, "Click")
    label := settings.AddText("x300 y220 w125 h24 +0x200", "RTSS executable")
    SettingsTrackControl("RTSS & Performance", label)
    pathEdit := settings.AddEdit("x430 y218 w350 h26")
    SettingsRegisterField("RTSS & Performance", "RTSS.Path", pathEdit, "Change")
    browse := settings.AddButton("x790 y217 w90 h28", "Browse...")
    browse.OnEvent("Click", SettingsBrowseRtss)
    SettingsTrackControl("RTSS & Performance", browse)
    overlayGroup := settings.AddGroupBox("x290 y265 w285 h270", "Overlay")
    SettingsTrackControl("RTSS & Performance", overlayGroup)
    label := settings.AddText("x305 y298 w75 h24 +0x200", "Mode")
    SettingsTrackControl("RTSS & Performance", label)
    overlayMode := settings.AddDropDownList(
        "x385 y296 w170 Choose1", ["Separate On / Off", "Toggle"])
    SettingsRegisterField(
        "RTSS & Performance", "RTSS.OverlayControlMode", overlayMode, "Change")
    SettingsAddShortcutAt(settings, "RTSS & Performance",
        "RTSS.OverlayOnShortcut", "On", 305, 340, 250)
    SettingsAddShortcutAt(settings, "RTSS & Performance",
        "RTSS.OverlayOffShortcut", "Off", 305, 386, 250)
    SettingsAddShortcutAt(settings, "RTSS & Performance",
        "RTSS.OverlayToggleShortcut", "Toggle", 305, 432, 250)

    limiterGroup := settings.AddGroupBox("x590 y265 w305 h270", "Frame Limiter")
    SettingsTrackControl("RTSS & Performance", limiterGroup)
    label := settings.AddText("x605 y298 w75 h24 +0x200", "Mode")
    SettingsTrackControl("RTSS & Performance", label)
    limiterMode := settings.AddDropDownList(
        "x685 y296 w190 Choose1", ["Separate On / Off", "Toggle"])
    SettingsRegisterField(
        "RTSS & Performance", "RTSS.FrameLimiterControlMode", limiterMode, "Change")
    label := settings.AddText("x605 y336 w120 h24 +0x200", "Cap label (FPS)")
    SettingsTrackControl("RTSS & Performance", label)
    capEdit := settings.AddEdit("x735 y334 w90 h26 Number")
    SettingsRegisterField("RTSS & Performance", "RTSS.CustomFrameCap", capEdit, "Change")
    SettingsAddShortcutAt(settings, "RTSS & Performance",
        "RTSS.FrameLimiterOnShortcut", "On", 605, 376, 270)
    SettingsAddShortcutAt(settings, "RTSS & Performance",
        "RTSS.FrameLimiterOffShortcut", "Off", 605, 422, 270)
    SettingsAddShortcutAt(settings, "RTSS & Performance",
        "RTSS.CustomFrameCapShortcut", "Toggle", 605, 468, 270)

    ; Advanced
    control := settings.AddText("x300 y185 w570 h72 +Wrap",
        "This companion deliberately contains no shell registration, Explorer control, "
        . "taskbar hiding, window sizing, focus scoring, or Steam lifecycle management.")
    SettingsTrackControl("Advanced", control)
    openIni := settings.AddButton("x300 y280 w175 h34", "Open INI")
    openIni.OnEvent("Click", (*) => Run(IniPath))
    SettingsTrackControl("Advanced", openIni)
    openLog := settings.AddButton("x490 y280 w175 h34", "Open Log")
    openLog.OnEvent("Click", (*) => Run(LogPath))
    SettingsTrackControl("Advanced", openLog)
    health := settings.AddButton("x680 y280 w175 h34", "Health Check")
    health.OnEvent("Click", ShowHealthCheck)
    SettingsTrackControl("Advanced", health)
    reloadButton := settings.AddButton("x300 y330 w175 h34", "Reload INI")
    reloadButton.OnEvent("Click", ReloadSettings)
    SettingsTrackControl("Advanced", reloadButton)
    parkButton := settings.AddButton("x490 y330 w175 h34", "Park Cursor Now")
    parkButton.OnEvent("Click", ParkCursor)
    SettingsTrackControl("Advanced", parkButton)
    exitButton := settings.AddButton("x680 y330 w175 h34", "Exit Companion")
    exitButton.OnEvent("Click", ExitCompanion)
    SettingsTrackControl("Advanced", exitButton)
    control := settings.AddText("x300 y405 w570 h72 +Wrap",
        "The heartbeat log proves whether the companion remains responsive while Xbox FSE is active.")
    SettingsTrackControl("Advanced", control)

    settings.AddText("x24 y566 w430 h26 vSettingsStatus", "All changes saved")
    saveButton := settings.AddButton("x620 y560 w135 h34 Default", "Save && Apply")
    saveButton.OnEvent("Click", SaveSettings)
    closeButton := settings.AddButton("x770 y560 w110 h34", "Close")
    closeButton.OnEvent("Click", CloseSettings)
    settings.OnEvent("Close", CloseSettings)
    settings.OnEvent("Escape", CloseSettings)
    SettingsGui := settings
    SettingsVisible := true
    SettingsPopulate()
    SettingsShowCategory(1)
    foreground := 0
    try foreground := WinExist("A")
    monitorIndex := GetMonitorIndexForWindow(foreground)
    CenterGuiOnMonitorActual(settings, monitorIndex, 920, 610)
}

SettingsTrackControl(category, control) {
    global SettingsCategoryControls
    SettingsCategoryControls[category].Push(control)
}

SettingsRegisterField(category, key, control, eventName := "Change") {
    global SettingsFields
    SettingsFields[key] := control
    SettingsTrackControl(category, control)
    control.OnEvent(eventName, SettingsMarkDirty)
}

SettingsAddEditRow(guiObj, category, key, labelText, y, numeric := false) {
    label := guiObj.AddText("x300 y" y " w250 h24 +0x200", labelText)
    SettingsTrackControl(category, label)
    options := "x570 y" (y - 2) " w150 h26"
    if numeric
        options .= " Number"
    edit := guiObj.AddEdit(options)
    SettingsRegisterField(category, key, edit, "Change")
}

SettingsAddShortcutAt(guiObj, category, key, labelText, x, y, totalWidth) {
    global SettingsFields
    label := guiObj.AddText("x" x " y" y " w55 h24 +0x200", labelText)
    SettingsTrackControl(category, label)
    editX := x + 58
    editWidth := totalWidth - 145
    edit := guiObj.AddEdit("x" editX " y" (y - 2) " w" editWidth " h26")
    SettingsRegisterField(category, key, edit, "Change")
    buttonX := editX + editWidth + 6
    button := guiObj.AddButton("x" buttonX " y" (y - 3) " w78 h28", "Record...")
    button.OnEvent("Click", SettingsRecordShortcut.Bind(key))
    SettingsTrackControl(category, button)
}

SettingsCategoryMeta(index) {
    categories := [
        ["General",
            "Quick Menu, heartbeat, and the controls shown in the living-room interface."],
        ["Controller & Cursor",
            "View/Back mappings, controller pointer behavior, cursor hiding, and parking."],
        ["RTSS & Performance",
            "RTSS executable, overlay shortcuts, frame-limiter shortcuts, and cap label."],
        ["Advanced",
            "Portable files, diagnostics, cursor test, reload, and companion lifecycle."]
    ]
    index := Max(1, Min(categories.Length, index))
    return categories[index]
}

SettingsCategoryChanged(control, *) {
    SettingsShowCategory(control.Value)
}

SettingsShowCategory(index) {
    global SettingsCategoryControls, SettingsCategoryList
    global SettingsCategoryTitleCtrl, SettingsCategoryDescriptionCtrl
    global SettingsCurrentCategory
    meta := SettingsCategoryMeta(index)
    SettingsCurrentCategory := index
    try SettingsCategoryList.Choose(index)
    SettingsCategoryTitleCtrl.Text := GuiSafeLabel(meta[1])
    SettingsCategoryDescriptionCtrl.Text := GuiSafeLabel(meta[2])
    for category, controls in SettingsCategoryControls {
        visible := category = meta[1]
        for _, control in controls
            try control.Visible := visible
    }
}

SettingsChangeCategory(direction) {
    global SettingsCurrentCategory
    nextCategory := SettingsCurrentCategory + direction
    if (nextCategory < 1)
        nextCategory := 4
    if (nextCategory > 4)
        nextCategory := 1
    SettingsShowCategory(nextCategory)
}

SettingsShortcutRow(guiObj, key, label, position) {
    global SettingsFields
    guiObj.AddText(position " w165 h24 +0x200", label)
    edit := guiObj.AddEdit("x190 yp w330 h26")
    SettingsFields[key] := edit
    edit.OnEvent("Change", SettingsMarkDirty)
    button := guiObj.AddButton("x+8 yp-1 w90 h28", "Record...")
    button.OnEvent("Click", SettingsRecordShortcut.Bind(key))
}

SettingsPopulate() {
    global SettingsFields, SettingsDirty, RtssPath
    if (SettingsFields.Count = 0)
        return
    SetFieldValue("QuickMenu.Enable", ReadBool("QuickMenu", "Enable", true))
    SetFieldValue("QuickMenu.ChordHoldMs", ReadInt("QuickMenu", "ChordHoldMs", 700, 250, 3000))
    SetFieldValue("Companion.HeartbeatSeconds",
        ReadInt("Companion", "HeartbeatSeconds", 60, 15, 3600))
    SetFieldValue("Audio.EnableQuickControls", ReadBool("Audio", "EnableQuickControls", true))
    SetFieldValue("Display.EnableQuickControls", ReadBool("Display", "EnableQuickControls", true))
    SetFieldValue("Controller.EnableControllerMouseMode",
        ReadBool("Controller", "EnableControllerMouseMode", true))
    SetFieldValue("Controller.ControllerIndex",
        ReadInt("Controller", "ControllerIndex", 0, 0, 3))
    SetFieldValue("Controller.ControllerDeadzone",
        ReadInt("Controller", "ControllerDeadzone", 4000, 1000, 16000))
    SetFieldValue("Controller.ControllerMouseSpeed",
        ReadInt("Controller", "ControllerMouseSpeed", 100, 10, 300))
    SetFieldValue("Controller.ControllerChordHoldMs",
        ReadInt("Controller", "ControllerChordHoldMs", 500, 200, 3000))
    SetFieldValue("Cursor.EnableAutoHide", ReadBool("Cursor", "EnableAutoHide", true))
    SetFieldValue("Cursor.HideDelayMs", ReadInt("Cursor", "HideDelayMs", 1000, 250, 10000))
    SetFieldValue("Cursor.ParkOnStartup", ReadBool("Cursor", "ParkOnStartup", true))
    SetFieldValue("Cursor.ParkOnSteamReturn", ReadBool("Cursor", "ParkOnSteamReturn", true))
    SetFieldValue("RTSS.EnableIntegration", ReadBool("RTSS", "EnableIntegration", false))
    SetFieldValue("RTSS.Path", ReadText("RTSS", "Path", RtssPath))
    SetDropDownMode("RTSS.OverlayControlMode",
        ReadText("RTSS", "OverlayControlMode", "separate"))
    SetFieldValue("RTSS.OverlayOnShortcut", ReadText("RTSS", "OverlayOnShortcut", "^+1"))
    SetFieldValue("RTSS.OverlayOffShortcut", ReadText("RTSS", "OverlayOffShortcut", "^+2"))
    SetFieldValue("RTSS.OverlayToggleShortcut", ReadText("RTSS", "OverlayToggleShortcut", "^+o"))
    SetDropDownMode("RTSS.FrameLimiterControlMode",
        ReadText("RTSS", "FrameLimiterControlMode", "separate"))
    SetFieldValue("RTSS.CustomFrameCap", ReadInt("RTSS", "CustomFrameCap", 0, 0, 1000))
    SetFieldValue("RTSS.FrameLimiterOnShortcut",
        ReadText("RTSS", "FrameLimiterOnShortcut", "^+5"))
    SetFieldValue("RTSS.FrameLimiterOffShortcut",
        ReadText("RTSS", "FrameLimiterOffShortcut", "^+6"))
    SetFieldValue("RTSS.CustomFrameCapShortcut",
        ReadText("RTSS", "CustomFrameCapShortcut", "^+f"))
    SettingsDirty := false
    SettingsUpdateStatus()
}

SetFieldValue(key, value) {
    global SettingsFields
    if SettingsFields.Has(key)
        SettingsFields[key].Value := value
}

SetDropDownMode(key, mode) {
    global SettingsFields
    if SettingsFields.Has(key)
        SettingsFields[key].Choose(StrLower(mode) = "toggle" ? 2 : 1)
}

GetFieldValue(key, fallback := "") {
    global SettingsFields
    if !SettingsFields.Has(key)
        return fallback
    return SettingsFields[key].Value
}

SaveSettings(*) {
    global IniPath, SettingsDirty
    pairs := [
        ["QuickMenu", "Enable", GetFieldValue("QuickMenu.Enable") ? "true" : "false"],
        ["QuickMenu", "ChordHoldMs", GetFieldValue("QuickMenu.ChordHoldMs", 700)],
        ["Companion", "HeartbeatSeconds", GetFieldValue("Companion.HeartbeatSeconds", 60)],
        ["Audio", "EnableQuickControls",
            GetFieldValue("Audio.EnableQuickControls") ? "true" : "false"],
        ["Display", "EnableQuickControls",
            GetFieldValue("Display.EnableQuickControls") ? "true" : "false"],
        ["Controller", "EnableControllerMouseMode",
            GetFieldValue("Controller.EnableControllerMouseMode") ? "true" : "false"],
        ["Controller", "ControllerIndex", GetFieldValue("Controller.ControllerIndex", 0)],
        ["Controller", "ControllerDeadzone", GetFieldValue("Controller.ControllerDeadzone", 4000)],
        ["Controller", "ControllerMouseSpeed", GetFieldValue("Controller.ControllerMouseSpeed", 100)],
        ["Controller", "ControllerChordHoldMs",
            GetFieldValue("Controller.ControllerChordHoldMs", 500)],
        ["Cursor", "EnableAutoHide",
            GetFieldValue("Cursor.EnableAutoHide") ? "true" : "false"],
        ["Cursor", "HideDelayMs", GetFieldValue("Cursor.HideDelayMs", 1000)],
        ["Cursor", "ParkOnStartup",
            GetFieldValue("Cursor.ParkOnStartup") ? "true" : "false"],
        ["Cursor", "ParkOnSteamReturn",
            GetFieldValue("Cursor.ParkOnSteamReturn") ? "true" : "false"],
        ["RTSS", "EnableIntegration",
            GetFieldValue("RTSS.EnableIntegration") ? "true" : "false"],
        ["RTSS", "Path", GetFieldValue("RTSS.Path")],
        ["RTSS", "OverlayControlMode",
            GetFieldValue("RTSS.OverlayControlMode") = 2 ? "toggle" : "separate"],
        ["RTSS", "OverlayOnShortcut", GetFieldValue("RTSS.OverlayOnShortcut")],
        ["RTSS", "OverlayOffShortcut", GetFieldValue("RTSS.OverlayOffShortcut")],
        ["RTSS", "OverlayToggleShortcut", GetFieldValue("RTSS.OverlayToggleShortcut")],
        ["RTSS", "FrameLimiterControlMode",
            GetFieldValue("RTSS.FrameLimiterControlMode") = 2 ? "toggle" : "separate"],
        ["RTSS", "CustomFrameCap", GetFieldValue("RTSS.CustomFrameCap", 0)],
        ["RTSS", "FrameLimiterOnShortcut", GetFieldValue("RTSS.FrameLimiterOnShortcut")],
        ["RTSS", "FrameLimiterOffShortcut", GetFieldValue("RTSS.FrameLimiterOffShortcut")],
        ["RTSS", "CustomFrameCapShortcut", GetFieldValue("RTSS.CustomFrameCapShortcut")]
    ]
    try {
        for _, pair in pairs
            IniWrite(pair[3], IniPath, pair[1], pair[2])
        SettingsDirty := false
        LoadSettings()
        ApplyRuntimeTimers()
        SettingsUpdateStatus("Saved and applied")
        SetStatus("Settings saved and applied")
    } catch as err {
        SettingsUpdateStatus("Save failed: " err.Message)
        SetStatus("Settings save failed: " err.Message, "Warning")
    }
}

CloseSettings(*) {
    global SettingsGui, SettingsVisible, SettingsDirty, SettingsDialogActive
    if !SettingsVisible
        return
    if SettingsDirty {
        SettingsDialogActive := true
        answer := MsgBox("Save changes before closing?", "SteamShell XFE Settings",
            "YesNoCancel Icon?")
        SettingsDialogActive := false
        if (answer = "Cancel")
            return
        if (answer = "Yes")
            SaveSettings()
    }
    try SettingsGui.Destroy()
    SettingsVisible := false
    SettingsDirty := false
}

SettingsOnSize(guiObj, minMax, width, height) {
    if (minMax = -1)
        return
    try guiObj["SettingsStatus"].Move(, height - 48, width - 360)
}

SettingsBrowseRtss(*) {
    global SettingsGui, SettingsDialogActive
    SettingsDialogActive := true
    path := FileSelect(1, , "Select RTSS.exe", "Programs (*.exe)")
    SettingsDialogActive := false
    if (path != "") {
        SetFieldValue("RTSS.Path", path)
        SettingsMarkDirty()
    }
    try WinActivate("ahk_id " SettingsGui.Hwnd)
}

SettingsRecordShortcut(key, *) {
    global SettingsDialogActive
    SettingsDialogActive := true
    result := RecordShortcutChord()
    SettingsDialogActive := false
    if result["ok"] {
        SetFieldValue(key, result["send"])
        SettingsMarkDirty()
    }
}

; ==============================================================================
; Controller mapping editor
; ==============================================================================
ControllerMappingKeys() {
    return [
        "A.Short", "A.Long", "B.Short", "B.Long", "X.Short", "X.Long",
        "Y.Short", "Y.Long", "LB.Short", "LB.Long", "RB.Short", "RB.Long",
        "LT.Short", "LT.Long", "RT.Short", "RT.Long", "Start.Short",
        "Start.Long", "L3.Short", "L3.Long", "R3.Short", "R3.Long"
    ]
}

ShowMappingEditor(*) {
    global MappingGui, MappingList
    if IsSet(MappingGui) {
        try MappingGui.Show()
        return
    }
    editor := Gui("+AlwaysOnTop +Resize +MinSize680x460", "Controller Mappings")
    editor.SetFont("s10", "Segoe UI")
    editor.AddText("xm ym w720 h42 +Wrap",
        "These actions run only while View/Back is held. "
        . "Select a row, then choose a built-in action or record a shortcut.")
    list := editor.AddListView("xm y+8 w720 h320 Grid -Multi", ["Input", "Action"])
    list.ModifyCol(1, 140)
    list.ModifyCol(2, 540)
    builtins := editor.AddDropDownList("xm y+12 w220 Choose1", [
        "None", "Left click", "Right click", "Enter", "Back / Escape",
        "Close window", "Touch keyboard", "Classic keyboard", "Game Bar",
        "Start menu", "File Explorer", "Application switcher", "Task Manager",
        "Task View", "Windows desktop", "Quick Menu", "Settings"
    ])
    applyBuiltin := editor.AddButton("x+8 yp-1 w130 h28", "Set Built-in")
    recordButton := editor.AddButton("x+8 yp w150 h28", "Record Shortcut...")
    resetButton := editor.AddButton("x+8 yp w130 h28", "Restore Defaults")
    closeButton := editor.AddButton("xm y+12 w140 h32", "Close")
    applyBuiltin.OnEvent("Click", MappingSetBuiltin.Bind(builtins))
    recordButton.OnEvent("Click", MappingRecordShortcut)
    resetButton.OnEvent("Click", MappingRestoreDefaults)
    closeButton.OnEvent("Click", CloseMappingEditor)
    editor.OnEvent("Close", CloseMappingEditor)
    editor.OnEvent("Escape", CloseMappingEditor)
    MappingGui := editor
    MappingList := list
    RefreshMappingList()
    editor.Show("AutoSize Center")
}

RefreshMappingList() {
    global MappingList
    if !IsObject(MappingList)
        return
    MappingList.Delete()
    for _, key in ControllerMappingKeys()
        MappingList.Add("", key, ControllerBindingPretty(key))
}

SelectedMappingKey() {
    global MappingList
    row := 0
    try row := MappingList.GetNext()
    if !row
        return ""
    return MappingList.GetText(row, 1)
}

MappingBuiltinValue(label) {
    values := Map(
        "None", "Builtin:None",
        "Left click", "Builtin:LeftClick",
        "Right click", "Builtin:RightClick",
        "Enter", "Builtin:Enter",
        "Back / Escape", "Builtin:Esc",
        "Close window", "Builtin:AltF4",
        "Touch keyboard", "Builtin:TabTip",
        "Classic keyboard", "Builtin:OSK",
        "Game Bar", "Builtin:WinG",
        "Start menu", "Builtin:StartMenu",
        "File Explorer", "Builtin:Explorer",
        "Application switcher", "Builtin:CtrlAltTab",
        "Task Manager", "Builtin:TaskManager",
        "Task View", "Builtin:TaskView",
        "Windows desktop", "Builtin:WindowsDesktop",
        "Quick Menu", "Builtin:QuickMenu",
        "Settings", "Builtin:Settings"
    )
    return values.Has(label) ? values[label] : "Builtin:None"
}

MappingSetBuiltin(dropDown, *) {
    global ControllerMap, ControllerMapDisplay, IniPath
    key := SelectedMappingKey()
    if (key = "") {
        SetStatus("Select a controller mapping first", "Warning")
        return
    }
    value := MappingBuiltinValue(dropDown.Text)
    ControllerMap[key] := value
    if ControllerMapDisplay.Has(key)
        ControllerMapDisplay.Delete(key)
    IniWrite(value, IniPath, "ControllerMap", key)
    try IniDelete(IniPath, "ControllerMap", key ".Display")
    RefreshMappingList()
    SetStatus(key " updated")
}

MappingRecordShortcut(*) {
    global ControllerMap, ControllerMapDisplay, IniPath, SettingsDialogActive
    key := SelectedMappingKey()
    if (key = "") {
        SetStatus("Select a controller mapping first", "Warning")
        return
    }
    SettingsDialogActive := true
    result := RecordShortcutChord()
    SettingsDialogActive := false
    if result["ok"] {
        ControllerMap[key] := "Send:" result["send"]
        ControllerMapDisplay[key] := result["display"]
        IniWrite("Send:" result["send"], IniPath, "ControllerMap", key)
        IniWrite(result["display"], IniPath, "ControllerMap", key ".Display")
        RefreshMappingList()
        SetStatus(key " recorded as " result["display"])
    }
}

MappingRestoreDefaults(*) {
    global ControllerMap, ControllerMapDisplay, IniPath
    answer := MsgBox("Restore every controller mapping to its default?",
        "Controller Mappings", "YesNo Icon?")
    if (answer != "Yes")
        return
    DefaultControllerMappings()
    for key, value in ControllerMap {
        IniWrite(value, IniPath, "ControllerMap", key)
        if ControllerMapDisplay.Has(key)
            IniWrite(ControllerMapDisplay[key], IniPath, "ControllerMap", key ".Display")
        else
            try IniDelete(IniPath, "ControllerMap", key ".Display")
    }
    RefreshMappingList()
    SetStatus("Controller mappings restored to defaults")
}

CloseMappingEditor(*) {
    global MappingGui, MappingList, SettingsDialogActive
    if IsSet(MappingGui)
        try MappingGui.Destroy()
    MappingGui := unset
    MappingList := 0
    SettingsDialogActive := false
}

; ==============================================================================
; Shortcut recorder
; ==============================================================================
GetPhysicalModsMap() {
    return Map(
        "Ctrl", GetKeyState("Ctrl", "P") || GetKeyState("LControl", "P")
            || GetKeyState("RControl", "P"),
        "Alt", GetKeyState("Alt", "P") || GetKeyState("LAlt", "P")
            || GetKeyState("RAlt", "P"),
        "Shift", GetKeyState("Shift", "P") || GetKeyState("LShift", "P")
            || GetKeyState("RShift", "P"),
        "Win", GetKeyState("LWin", "P") || GetKeyState("RWin", "P")
    )
}

RecordShortcutChord() {
    global _ShortcutCap
    result := Map("ok", false, "send", "", "display", "")
    capture := Gui("+AlwaysOnTop -MinimizeBox +ToolWindow", "Record Shortcut")
    capture.SetFont("s10", "Segoe UI")
    capture.AddText("xm", "Press one shortcut chord, then choose OK.")
    capture.SetFont("s12 Bold", "Consolas")
    preview := capture.AddText("xm y+10 w420 h30", "(none)")
    capture.SetFont("s10 Norm", "Segoe UI")
    okButton := capture.AddButton("xm y+10 w90 Default", "OK")
    cancelButton := capture.AddButton("x+10 yp w90", "Cancel")
    _ShortcutCap := Map(
        "gui", capture,
        "preview", preview,
        "input", 0,
        "mainKey", "",
        "liveMods", Map("Ctrl", false, "Alt", false, "Shift", false, "Win", false),
        "snapMods", Map("Ctrl", false, "Alt", false, "Shift", false, "Win", false),
        "done", false,
        "cancelled", false
    )
    okButton.OnEvent("Click", RecordShortcutAccept)
    cancelButton.OnEvent("Click", RecordShortcutCancel)
    capture.OnEvent("Close", RecordShortcutCancel)
    capture.OnEvent("Escape", RecordShortcutCancel)
    input := InputHook()
    input.NotifyNonText := true
    input.KeyOpt("{All}", "NS")
    input.OnKeyDown := RecordShortcutKeyDown
    input.OnKeyUp := RecordShortcutKeyUp
    _ShortcutCap["input"] := input
    capture.Show("AutoSize Center")
    input.Start()
    while IsObject(_ShortcutCap) && !_ShortcutCap["done"]
        Sleep 30
    if !IsObject(_ShortcutCap)
        return result
    cancelled := _ShortcutCap["cancelled"]
    mainKey := _ShortcutCap["mainKey"]
    mods := _ShortcutCap["snapMods"]
    try _ShortcutCap["input"].Stop()
    try _ShortcutCap["gui"].Destroy()
    _ShortcutCap := ""
    if (cancelled || mainKey = "")
        return result
    shortcut := ""
    display := ""
    if mods["Ctrl"]
        shortcut .= "^", display .= "Ctrl+"
    if mods["Alt"]
        shortcut .= "!", display .= "Alt+"
    if mods["Shift"]
        shortcut .= "+", display .= "Shift+"
    if mods["Win"]
        shortcut .= "#", display .= "Win+"
    shortcut .= NormalizeKeyForSend(mainKey)
    display .= NormalizeKeyForDisplay(mainKey)
    result["ok"] := true
    result["send"] := shortcut
    result["display"] := display
    return result
}

RecordShortcutKeyDown(inputObj, vk, sc) {
    global _ShortcutCap
    if !IsObject(_ShortcutCap)
        return
    keyName := GetKeyName(Format("vk{:x}sc{:x}", vk, sc))
    if (keyName = "" || keyName = "Unknown")
        return
    if (keyName = "Escape") {
        RecordShortcutCancel()
        return
    }
    if RecordShortcutSetModifier(keyName, true) {
        if (_ShortcutCap["mainKey"] = "")
            RecordShortcutUpdatePreview()
        return
    }
    _ShortcutCap["mainKey"] := keyName
    _ShortcutCap["snapMods"] := RecordShortcutGetLiveMods()
    RecordShortcutUpdatePreview()
}

RecordShortcutKeyUp(inputObj, vk, sc) {
    global _ShortcutCap
    if !IsObject(_ShortcutCap)
        return
    keyName := GetKeyName(Format("vk{:x}sc{:x}", vk, sc))
    if RecordShortcutSetModifier(keyName, false) && _ShortcutCap["mainKey"] = ""
        RecordShortcutUpdatePreview()
}

RecordShortcutSetModifier(keyName, isDown) {
    global _ShortcutCap
    if !IsObject(_ShortcutCap)
        return false
    modifier := ""
    switch keyName {
        case "Ctrl", "Control", "LControl", "RControl", "LCtrl", "RCtrl":
            modifier := "Ctrl"
        case "Alt", "LAlt", "RAlt", "Menu", "LMenu", "RMenu":
            modifier := "Alt"
        case "Shift", "LShift", "RShift":
            modifier := "Shift"
        case "Win", "LWin", "RWin":
            modifier := "Win"
        default:
            return false
    }
    _ShortcutCap["liveMods"][modifier] := isDown
    return true
}

RecordShortcutGetLiveMods() {
    global _ShortcutCap
    mods := Map("Ctrl", false, "Alt", false, "Shift", false, "Win", false)
    try {
        for key, value in _ShortcutCap["liveMods"] {
            if value
                mods[key] := true
        }
    }
    physical := GetPhysicalModsMap()
    for key, value in physical {
        if value
            mods[key] := true
    }
    return mods
}

RecordShortcutUpdatePreview() {
    global _ShortcutCap
    if !IsObject(_ShortcutCap)
        return
    mainKey := _ShortcutCap["mainKey"]
    mods := mainKey != "" ? _ShortcutCap["snapMods"] : RecordShortcutGetLiveMods()
    text := ""
    if mods["Ctrl"]
        text .= "Ctrl+"
    if mods["Alt"]
        text .= "Alt+"
    if mods["Shift"]
        text .= "Shift+"
    if mods["Win"]
        text .= "Win+"
    if (mainKey != "")
        text .= NormalizeKeyForDisplay(mainKey)
    if (text = "")
        text := "(none)"
    try _ShortcutCap["preview"].Text := text
}

RecordShortcutAccept(*) {
    global _ShortcutCap
    if IsObject(_ShortcutCap)
        _ShortcutCap["done"] := true
}

RecordShortcutCancel(*) {
    global _ShortcutCap
    if !IsObject(_ShortcutCap)
        return
    _ShortcutCap["cancelled"] := true
    try _ShortcutCap["input"].Stop()
    _ShortcutCap["done"] := true
}

NormalizeKeyForSend(keyName) {
    key := keyName
    if (key = "Escape")
        key := "Esc"
    if (key = "Return")
        key := "Enter"
    return StrLen(key) > 1 ? "{" key "}" : key
}

NormalizeKeyForDisplay(keyName) {
    if (keyName = "Escape")
        return "Esc"
    if (keyName = "Return")
        return "Enter"
    return keyName
}

; ==============================================================================
; Diagnostics
; ==============================================================================
ShowHealthCheck(*) {
    global AppVersion, IniPath, LogPath, ControllerIndex, RtssPath
    global EnableRTSSIntegration
    controller := Buffer(16, 0)
    controllerText := XInputGetState(ControllerIndex, &controller) = 0
        ? "PASS — controller detected at index " ControllerIndex
        : "WARN — no controller at index " ControllerIndex
    rtssText := !EnableRTSSIntegration
        ? "INFO — RTSS integration disabled"
        : (FileExist(NormalizePath(RtssPath))
            ? "PASS — RTSS executable found"
            : "WARN — RTSS executable not found")
    anyFseText := ProcessExist("AnyFSE.exe")
        ? "PASS — AnyFSE process detected"
        : "INFO — AnyFSE process not detected"
    lines := [
        "SteamShell XFE Companion " AppVersion,
        "",
        FileExist(IniPath) ? "PASS — settings file available" : "FAIL — settings file missing",
        controllerText,
        rtssText,
        anyFseText,
        ProcessExist("steam.exe") ? "PASS — Steam process detected" : "INFO — Steam not running",
        "",
        "Architecture: " (A_PtrSize = 8 ? "64-bit" : "32-bit"),
        "Administrator: " (A_IsAdmin ? "Yes" : "No (recommended)"),
        "Log: " LogPath,
        "",
        "The companion does not modify Winlogon Shell or manage Explorer/taskbar."
    ]
    message := ""
    for _, line in lines
        message .= line "`r`n"
    health := Gui("+AlwaysOnTop +ToolWindow", "SteamShell XFE Health Check")
    health.SetFont("s10", "Segoe UI")
    health.AddEdit("xm ym w650 h360 ReadOnly -Wrap", message)
    close := health.AddButton("xm y+10 w120 h32 Default", "Close")
    close.OnEvent("Click", (*) => health.Destroy())
    health.OnEvent("Escape", (*) => health.Destroy())
    health.Show("AutoSize Center")
    SetStatus("Health check completed")
}

; ==============================================================================
; Controller poll loop
; ==============================================================================
ResetControllerHoldState(downTick, longFired, triggerDown, buttonDefinitions) {
    for definition in buttonDefinitions {
        name := definition[1]
        downTick[name] := 0
        longFired[name] := false
    }
    downTick["LT"] := 0
    downTick["RT"] := 0
    longFired["LT"] := false
    longFired["RT"] := false
    triggerDown["LT"] := false
    triggerDown["RT"] := false
}

PollController() {
    global EnableControllerMouseMode, ControllerIndex, ControllerDeadzone
    global ControllerMouseSpeed, ControllerMouseFastMultiplier
    global ControllerScrollIntervalMs, ControllerScrollStep, ControllerChordHoldMs
    global QuickMenuVisible, EnableQuickMenu, QuickMenuChordHoldMs
    global SettingsVisible, SettingsDialogActive

    static state := Buffer(16, 0)
    static previousButtons := 0
    static previousViewDown := false
    static quickChordSince := 0
    static quickChordFired := false
    static lastScroll := 0
    static downTick := Map()
    static longFired := Map()
    static triggerDown := Map("LT", false, "RT", false)
    static settingsLtDown := false
    static settingsRtDown := false
    static inPoll := false
    static buttonDefinitions := [
        ["A", 0x1000], ["B", 0x2000], ["X", 0x4000], ["Y", 0x8000],
        ["LB", 0x0100], ["RB", 0x0200], ["Start", 0x0010],
        ["L3", 0x0040], ["R3", 0x0080]
    ]

    if inPoll
        return
    inPoll := true
    try {
        for definition in buttonDefinitions {
            name := definition[1]
            if !downTick.Has(name)
                downTick[name] := 0
            if !longFired.Has(name)
                longFired[name] := false
        }
        if !downTick.Has("LT")
            downTick["LT"] := 0
        if !downTick.Has("RT")
            downTick["RT"] := 0
        if !longFired.Has("LT")
            longFired["LT"] := false
        if !longFired.Has("RT")
            longFired["RT"] := false

        if (XInputGetState(ControllerIndex, &state) != 0) {
            previousButtons := 0
            previousViewDown := false
            quickChordSince := 0
            quickChordFired := false
            ResetControllerHoldState(downTick, longFired, triggerDown, buttonDefinitions)
            return
        }

        now := A_TickCount
        buttons := NumGet(state, 4, "UShort")
        lt := NumGet(state, 6, "UChar")
        rt := NumGet(state, 7, "UChar")
        lx := NumGet(state, 8, "Short")
        ly := NumGet(state, 10, "Short")
        rx := NumGet(state, 12, "Short")
        ry := NumGet(state, 14, "Short")
        pressed := buttons & ~previousButtons
        released := (~buttons) & previousButtons
        previousButtons := buttons

        if (Abs(lx) < ControllerDeadzone)
            lx := 0
        if (Abs(ly) < ControllerDeadzone)
            ly := 0
        if (Abs(rx) < ControllerDeadzone)
            rx := 0
        if (Abs(ry) < ControllerDeadzone)
            ry := 0

        ; Fallback Settings chord: LT + RT + LB + RB + L3 + R3.
        static settingsComboWasDown := false
        settingsComboDown := lt > 30 && rt > 30
            && (buttons & 0x0100) && (buttons & 0x0200)
            && (buttons & 0x0040) && (buttons & 0x0080)
        if (settingsComboDown && !settingsComboWasDown)
            ShowSettings()
        settingsComboWasDown := settingsComboDown

        ; Quick Menu: hold L3 + R3 with no conflicting chord buttons.
        quickChordDown := EnableQuickMenu
            && (buttons & 0x0040) && (buttons & 0x0080)
            && !(buttons & 0x0020) && !(buttons & 0x0010)
            && !(buttons & 0x0100) && !(buttons & 0x0200)
            && lt <= 30 && rt <= 30
        if quickChordDown {
            if !quickChordSince
                quickChordSince := now
            if (!quickChordFired && now - quickChordSince >= QuickMenuChordHoldMs) {
                quickChordFired := true
                ToggleQuickMenu()
                return
            }
        } else {
            quickChordSince := 0
            quickChordFired := false
        }

        if QuickMenuVisible {
            QuickMenuHandleController(pressed, lx, ly)
            return
        }

        ; Settings owns right-stick pointer and RB click without requiring Back.
        if SettingsVisible {
            if (rx != 0 || ry != 0) {
                dx := Round((rx / 32767.0) * ControllerMouseSpeed)
                dy := Round((-ry / 32767.0) * ControllerMouseSpeed)
                if (dx != 0 || dy != 0)
                    try MouseMove(dx, dy, 0, "R")
            }
            if (ly != 0 && now - lastScroll >= ControllerScrollIntervalMs) {
                lastScroll := now
                try Send(ly > 0 ? "{WheelUp}" : "{WheelDown}")
            }
            if !SettingsDialogActive {
                if (pressed & 0x0200)
                    try Click("Left")
                if (pressed & 0x1000)
                    try SendInput("{Enter}")
                if (pressed & 0x2000)
                    try SendInput("{Esc}")
                if (pressed & 0x4000)
                    OpenTouchKeyboard()
                if (pressed & 0x0001)
                    try SendInput("{Up}")
                if (pressed & 0x0002)
                    try SendInput("{Down}")
                if (pressed & 0x0004)
                    try SendInput("{Left}")
                if (pressed & 0x0008)
                    try SendInput("{Right}")
                currentLtDown := lt > 30
                currentRtDown := rt > 30
                if (currentLtDown && !settingsLtDown && !currentRtDown)
                    SettingsChangeCategory(-1)
                if (currentRtDown && !settingsRtDown && !currentLtDown)
                    SettingsChangeCategory(1)
                if (pressed & 0x8000)
                    SaveSettings()
                settingsLtDown := currentLtDown
                settingsRtDown := currentRtDown
            }
            previousViewDown := false
            ResetControllerHoldState(downTick, longFired, triggerDown, buttonDefinitions)
            return
        }
        settingsLtDown := false
        settingsRtDown := false

        if !EnableControllerMouseMode {
            previousViewDown := false
            ResetControllerHoldState(downTick, longFired, triggerDown, buttonDefinitions)
            return
        }

        viewDown := (buttons & 0x0020) != 0
        if !viewDown {
            previousViewDown := false
            ResetControllerHoldState(downTick, longFired, triggerDown, buttonDefinitions)
            return
        }

        if !previousViewDown {
            for definition in buttonDefinitions {
                name := definition[1]
                mask := definition[2]
                if (buttons & mask) {
                    downTick[name] := now
                    longFired[name] := false
                }
            }
            if (lt > 30)
                downTick["LT"] := now, triggerDown["LT"] := true
            if (rt > 30)
                downTick["RT"] := now, triggerDown["RT"] := true
        }
        previousViewDown := true

        if (rx != 0 || ry != 0) {
            speed := rt > 30
                ? Round(ControllerMouseSpeed * ControllerMouseFastMultiplier)
                : ControllerMouseSpeed
            dx := Round((rx / 32767.0) * speed)
            dy := Round((-ry / 32767.0) * speed)
            if (dx != 0 || dy != 0)
                try MouseMove(dx, dy, 0, "R")
        }
        if (ly != 0 && now - lastScroll >= ControllerScrollIntervalMs) {
            lastScroll := now
            Loop ControllerScrollStep
                try Send(ly > 0 ? "{WheelUp}" : "{WheelDown}")
        }

        for definition in buttonDefinitions {
            name := definition[1]
            mask := definition[2]
            if (pressed & mask)
                downTick[name] := now, longFired[name] := false
            if ((buttons & mask) && !longFired[name] && downTick[name]
                && now - downTick[name] >= ControllerChordHoldMs
                && HasLongBinding(name)) {
                longFired[name] := true
                ExecuteControllerBinding(name ".Long")
            }
            if ((released & mask) && downTick[name]) {
                if !longFired[name]
                    ExecuteControllerBinding(name ".Short")
                downTick[name] := 0
                longFired[name] := false
            }
        }

        for _, triggerName in ["LT", "RT"] {
            isDown := triggerName = "LT" ? lt > 30 : rt > 30
            justPressed := isDown && !triggerDown[triggerName]
            justReleased := !isDown && triggerDown[triggerName]
            triggerDown[triggerName] := isDown
            if justPressed
                downTick[triggerName] := now, longFired[triggerName] := false
            if (isDown && !longFired[triggerName] && downTick[triggerName]
                && now - downTick[triggerName] >= ControllerChordHoldMs
                && HasLongBinding(triggerName)) {
                longFired[triggerName] := true
                ExecuteControllerBinding(triggerName ".Long")
            }
            if (justReleased && downTick[triggerName]) {
                if !longFired[triggerName]
                    ExecuteControllerBinding(triggerName ".Short")
                downTick[triggerName] := 0
                longFired[triggerName] := false
            }
        }

        if (pressed & 0x0001)
            try SendInput("{Up}")
        if (pressed & 0x0002)
            try SendInput("{Down}")
        if (pressed & 0x0004)
            try SendInput("{Left}")
        if (pressed & 0x0008)
            try SendInput("{Right}")
        if (pressed & 0x0400)
            ExecuteControllerBinding("Y.Short")
    } finally {
        inPoll := false
    }
}

; ==============================================================================
; Startup
; ==============================================================================
OnExit(OnCompanionExit)
EnsureSettingsFile()
LoadSettings()
ApplyRuntimeTimers()
LogLine("Started SteamShell XFE Companion " AppVersion
    . " (PID " ScriptPid ", " (A_IsAdmin ? "administrator" : "standard user") ").")
if ParkOnStartup
    SetTimer(ParkCursor, -1000)

Hotkey("^!+q", ToggleQuickMenu)
Hotkey("^!+s", ShowSettings)
Hotkey("^!+r", ReloadSettings)
Hotkey("^!+x", ExitCompanion)
