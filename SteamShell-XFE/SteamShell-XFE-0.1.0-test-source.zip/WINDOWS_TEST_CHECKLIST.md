# SteamShell XFE Windows test checklist

Test this separately from the locked SteamShell 1.5.0 build.

## Build and launch

- Run `Build-SteamShell-XFE.ps1` with AutoHotkey v2.0.26 64-bit installed.
- Confirm static validation and `/Validate` both pass.
- Launch the EXE as a standard user; do not enable **Run as administrator**.
- Confirm a second launch leaves the original process running.
- Confirm `SteamShell-XFE.ini` and `SteamShell-XFE.log` appear beside the EXE.

## AnyFSE lifecycle

- Configure Steam Big Picture as the AnyFSE Home app.
- Add SteamShell-XFE.exe as an AnyFSE startup app.
- Turn **Exit FSE when Home app exits** off.
- Enter Xbox FSE and wait at least two heartbeat intervals.
- Close and relaunch Steam; confirm the same companion PID survives.
- Switch to the Windows desktop and back; confirm the companion survives.
- Re-enter Xbox FSE; confirm no duplicate companion process is created.

## Controller and UI

- Hold L3 + R3 for 700 ms; confirm the Quick Menu opens once.
- Navigate every page with D-pad, A, and B.
- Open Settings and confirm right-stick pointer, RB click, D-pad, LT/RT tabs,
  and Y save work.
- Verify View/Back mappings, including short and long actions.
- Record an RTSS shortcut and a controller shortcut; save, restart, and retest.

## Utilities

- Cycle audio outputs, adjust volume, and toggle mute.
- Toggle HDR.
- Change resolution/refresh, do not confirm, and verify automatic revert.
- Repeat and select the current marked mode to keep it.
- Verify RTSS Overlay On/Off defaults (`Ctrl+Shift+1` / `Ctrl+Shift+2`).
- Verify limiter On/Off defaults (`Ctrl+Shift+5` / `Ctrl+Shift+6`).
- Verify touch keyboard and classic OSK.
- Open native Task View, Game Bar, and Windows Desktop.

## Cursor and sleep

- Confirm startup parking moves the hidden cursor to the left edge.
- Move the cursor, launch/exit a game, and confirm Steam-return parking.
- Run `powercfg /requests`; confirm SteamShell XFE creates no request.
- Leave the PC idle through the configured display-off and sleep timers.
- Confirm the log heartbeat does not prevent display-off or S0 sleep.

## Non-interference

- Confirm Xbox FSE still owns window maximization, centering, Task View, and
  desktop switching.
- Confirm the companion never writes the Winlogon Shell registry value.
- Confirm it never kills/restarts Explorer, hides the taskbar, launches Steam,
  or forces another application to the foreground.
- Exercise Steam exit/restart and non-Steam apps for at least one longer play
  session before treating this as a release candidate.
